<!DOCTYPE html>
<html>
  <head lang="en">
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    
    <title>Package Booking Invoice</title>

    
    <link
      rel="shortcut icon"
      type="image/png"
      href="<?php echo e(asset('assets/img/' . $websiteInfo->favicon)); ?>"
    >

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
  </head>

  <body>
    <div class="package-booking-invoice my-5">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="logo text-center" style="margin-bottom: 35px;">
              <img src="<?php echo e(asset('assets/img/' . $websiteInfo->logo)); ?>" alt="Company Logo">
            </div>

            <div class="mb-3">
              <h2 class="text-center">
                <?php echo e(__('PACKAGE BOOKING INVOICE')); ?>

              </h2>
            </div>

            <?php
              $position = $bookingInfo->currency_text_position;
              $currency = $bookingInfo->currency_text;
            ?>

            <div class="row">
              <div class="col">
                <table class="table table-striped table-bordered">
                  <tbody>
                    <tr>
                      <th scope="col"><?php echo e(__('Booking Number:')); ?></th>
                      <td><?php echo e('#' . $bookingInfo->booking_number); ?></td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Booking Date:')); ?></th>
                      <td>
                        <?php echo e(date_format($bookingInfo->created_at, 'M d, Y')); ?>

                      </td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Package Name:')); ?></th>
                      <td>
                        <?php echo e($bookingInfo->tourPackage->packageContent()->where('language_id', $currentLanguageInfo->id)->first()->title); ?>

                      </td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Visitors:')); ?></th>
                      <td>
                        <?php echo e($bookingInfo->visitors); ?>

                      </td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Subtotal:')); ?></th>
                      <td class="text-capitalize">
                        <?php echo e($position == 'left' ? $currency . ' ' : ''); ?><?php echo e($bookingInfo->subtotal); ?><?php echo e($position == 'right' ? ' ' . $currency : ''); ?>

                      </td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Discount:')); ?></th>
                      <td class="text-capitalize">
                        <?php echo e($position == 'left' ? $currency . ' ' : ''); ?><?php echo e($bookingInfo->discount); ?><?php echo e($position == 'right' ? ' ' . $currency : ''); ?>

                      </td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Total Cost:')); ?></th>
                      <td class="text-capitalize">
                        <?php echo e($position == 'left' ? $currency . ' ' : ''); ?><?php echo e($bookingInfo->grand_total); ?><?php echo e($position == 'right' ? ' ' . $currency : ''); ?>

                      </td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Customer Name:')); ?></th>
                      <td><?php echo e($bookingInfo->customer_name); ?></td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Customer Phone:')); ?></th>
                      <td><?php echo e($bookingInfo->customer_phone); ?></td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Paid via:')); ?></th>
                      <td><?php echo e($bookingInfo->payment_method); ?></td>
                    </tr>

                    <tr>
                      <th scope="col"><?php echo e(__('Payment Status:')); ?></th>
                      <td>
                        <?php if($bookingInfo->payment_status == 1): ?>
                          <?php echo e(__('Complete')); ?>

                        <?php else: ?>
                          <?php echo e(__('Incomplete')); ?>

                        <?php endif; ?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/pdf/package_booking.blade.php ENDPATH**/ ?>