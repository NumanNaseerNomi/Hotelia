<div class="header-menu-area">
  <div class="container-fluid">
    <div class="row align-items-center">
      <div class="col-lg-2 col-md-4 col-7">
        <?php if(!is_null($websiteInfo->logo)): ?>
          <div class="logo">
            <a href="<?php echo e(route('index')); ?>">
              <img class="lazy" data-src="<?php echo e(asset('assets/img/' . $websiteInfo->logo)); ?>" alt="website logo">
            </a>
          </div>
        <?php endif; ?>
      </div>

      <div class="col-lg-10 col-md-8 col-5">
        <div class="menu-right-area text-right">
          <div class="lang-select">
            <div class="lang-img">
                <img class="lazy" data-src="<?php echo e(asset('assets/img/icons/languages.png')); ?>" alt="flag" width="45">
            </div>

            <div class="lang-option">
              <form action="<?php echo e(route('change_language')); ?>" method="GET">
                <select class="nice-select" name="lang_code" onchange="this.form.submit()">
                  <?php $__currentLoopData = $allLanguageInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $languageInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                      value="<?php echo e($languageInfo->code); ?>"
                      <?php echo e($languageInfo->code == $currentLanguageInfo->code ? 'selected' : ''); ?>

                    >
                      <?php echo e($languageInfo->name); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </form>
            </div>
          </div>

          <?php
                $links = json_decode($menus, true);
          ?>
          <nav class="main-menu">
            <ul class="list-inline">
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $href = getHref($link, $currentLanguageInfo->id);
                    ?>

                    <?php if(!array_key_exists("children",$link)): ?>

                        
                        <li><a href="<?php echo e($href); ?>" target="<?php echo e($link["target"]); ?>"><?php echo e($link["text"]); ?></a></li>

                    <?php else: ?>
                        <li class="have-submenu">
                            
                            <a href="<?php echo e($href); ?>" target="<?php echo e($link["target"]); ?>"><?php echo e($link["text"]); ?></a>

                            <ul class="submenu">
                                
                                <?php $__currentLoopData = $link["children"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $l2Href = getHref($level2, $currentLanguageInfo->id);
                                    ?>

                                    <li <?php if(array_key_exists("children", $level2)): ?> class="have-submenu" <?php endif; ?>>
                                        <a  href="<?php echo e($l2Href); ?>" target="<?php echo e($level2["target"]); ?>"><?php echo e($level2["text"]); ?></a>

                                        <?php if(array_key_exists("children", $level2)): ?>
                                        <ul class="submenu">
                                            <?php $__currentLoopData = $level2["children"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $l3Href = getHref($level3, $currentLanguageInfo->id);
                                                ?>
                                                <li><a  href="<?php echo e($l3Href); ?>" target="<?php echo e($level3["target"]); ?>"><?php echo e($level3["text"]); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>

                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </nav>

        </div>
      </div>
    </div>

    <div class="mobilemenu"></div>
  </div>
</div>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/partials/header_nav_one.blade.php ENDPATH**/ ?>