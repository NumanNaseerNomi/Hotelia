<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Package Details')); ?>

<?php $__env->stopSection(); ?>

<?php
  $metaKeys = !empty($details->meta_keywords) ? $details->meta_keywords : '';
  $metaDesc = !empty($details->meta_description) ? $details->meta_description : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy"
      data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>">
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(strlen($details->title) > 30 ? mb_substr($details->title, 0, 30, 'utf-8') . '...' : $details->title); ?>

          </h1>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>

            <li><?php echo e(__('Package Details')); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <section class="packages-details-area">
      <div class="container details-wrapper">
        
        <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="row">
            <div class="col">
              <div class="alert alert-danger alert-block">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="close" data-dismiss="alert">×</button>
              </div>
            </div>
          </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="row">
            <div class="col">
              <div class="alert alert-danger alert-block">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="close" data-dismiss="alert">×</button>
              </div>
            </div>
          </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="row">
          <div class="col-lg-8">
            <div class="packages-details-wrapper">

              <div class="gallery-wrap box-wrap">
                <div class="packages-big-slider">
                  <?php
                    $sliderImgs = json_decode($details->package->slider_imgs);
                  ?>

                  <?php $__currentLoopData = $sliderImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-item">
                      <a href="<?php echo e(asset('assets/img/packages/slider_images/' . $image)); ?>" class="gallery-single">
                        <img src="<?php echo e(asset('assets/img/packages/slider_images/' . $image)); ?>" alt="image">
                      </a>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="packages-thumb-slider">
                  <?php $__currentLoopData = $sliderImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thumbImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-item">
                      <img src="<?php echo e(asset('assets/img/packages/slider_images/' . $thumbImg)); ?>" alt="image">
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>

              <p id="package-id" class="d-none"><?php echo e($details->package_id); ?></p>

              <div class="discription-box box-wrap">
                <h4 class="title"><?php echo e(convertUtf8($details->title)); ?></h4>
                <p><?php echo replaceBaseUrl($details->description, 'summernote'); ?></p>
              </div>

              <?php if(count($plans) > 0): ?>
                <div class="schedule-wrapp box-wrap">
                  <?php if($details->package->plan_type == 'daywise'): ?>
                    <h4 class="title"><?php echo e(__('Detailed Day-wise Itinerary')); ?></h4>

                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="single-schedule">
                        <div class="icon">
                          <i class="far fa-calendar-alt"></i>
                        </div>
                        <div class="content">
                          <h4><?php echo e(__('Day') . '-' . $plan->day_number . ' : ' . $plan->title); ?></h4>
                          <p><?php echo replaceBaseUrl($plan->plan, 'summernote'); ?></p>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php elseif($details->package->plan_type == 'timewise'): ?>
                    <h4 class="title"><?php echo e(__('Detailed Time-wise Itinerary')); ?></h4>
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="single-schedule">
                        <div class="icon">
                          <i class="far fa-clock"></i>
                        </div>
                        <div class="content">
                          <h4><?php echo e($plan->start_time . ' - ' . $plan->end_time . ' : ' . $plan->title); ?></h4>
                          <p><?php echo replaceBaseUrl($plan->plan, 'summernote'); ?></p>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </div>
              <?php endif; ?>

              <?php if(count($locations) > 0): ?>
                <div class="places-box box-wrap">
                  <h4 class="title"><?php echo e(__('Places Will Be Covered')); ?></h4>
                  <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#" data-toggle="modal" title="<?php echo e(__('Click here to see in map')); ?>"
                      data-target="#locationModal<?php echo e($location->id); ?>"><?php echo e($location->name); ?></a>

                    <!-- Location Modal -->
                    <?php if(!empty($location->latitude) && !empty($location->longitude)): ?>
                      <div class="modal fade" id="locationModal<?php echo e($location->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLongTitle">
                                <?php echo e($location->name . ' ' . __('on Map')); ?></h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body p-0">
                              <iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0"
                                marginwidth="0"
                                src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php echo e($location->latitude); ?>,%20<?php echo e($location->longitude); ?>+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>

              <?php if($details->package->pricing_type != 'negotiable'): ?>
                <div class="review-area box-wrap <?php echo e($status->package_rating_status == 0 ? 'd-none' : ''); ?>">
                  <h4 class="title"><?php echo e(__('Client’s Reviews')); ?></h4>

                  <?php if(count($reviews) == 0): ?>
                    <div class="py-4 bg-light mb-2">
                      <h5 class="text-center mb-3"><?php echo e(__('This Package Has No Review Yet.')); ?></h5>
                    </div>
                  <?php else: ?>
                    <ul class="review-list">
                      <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                          <?php
                            $user = $review->packageReviewedByUser()->first();
                          ?>

                          <div class="review-user">
                            <img class="lazy"
                              data-src="<?php echo e(!empty($user->image) ? asset('assets/img/users/' . $user->image) : asset('assets/img/user-profile.jpg')); ?>"
                              alt="user image">
                          </div>

                          <div class="review-desc">
                            <div class="rate mb-2">
                              <div class="rating" style="width:<?php echo e($review->rating * 20); ?>%"></div>
                            </div>

                            <h6><?php echo e($user->first_name . ' ' . $user->last_name); ?> <span class="review-date">
                                <?php echo e(date_format($review->updated_at, 'd M Y')); ?></span></h6>

                            <p><?php echo e($review->comment); ?></p>
                          </div>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  <?php endif; ?>
                </div>
              <?php endif; ?>

              <?php if($status->package_rating_status == 1): ?>
                <?php if(auth()->guard('web')->guest()): ?>
                  <h4><a href="<?php echo e(route('user.login', ['redirectPath' => 'package_details'])); ?>"><?php echo e(__('Login')); ?></a>
                    <?php echo e(__('To Give Your Review')); ?>.</h4>
                <?php endif; ?>

                <?php if(auth()->guard('web')->check()): ?>
                  <?php if($details->package->pricing_type != 'negotiable'): ?>
                    <div class="review-form box-wrap">
                      <h4 class="title"><?php echo e(__('Give Your Review')); ?></h4>
                      <form action="<?php echo e(route('package.store_review', ['id' => $details->package_id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                          <div class="col-12">
                            <div class="mb-25">
                              <div class="review-content">
                                <ul class="review-value review-1">
                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="1">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>
                                </ul>

                                <ul class="review-value review-2">
                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="2">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="2">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>
                                </ul>

                                <ul class="review-value review-3">
                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="3">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="3">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="3">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>
                                </ul>

                                <ul class="review-value review-4">
                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="4">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="4">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="4">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="4">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>
                                </ul>

                                <ul class="review-value review-5">
                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="5">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="5">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="5">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="5">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>

                                  <li>
                                    <a class="cursor-pointer" data-ratingVal="5">
                                      <i class="far fa-star"></i>
                                    </a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>

                          <input type="hidden" id="ratingId" name="rating">

                          <div class="col-12">
                            <div class="input-wrap text-area">
                              <textarea placeholder="<?php echo e(__('Review')); ?>" name="comment"><?php echo e(old('comment')); ?></textarea>
                              <i class="far fa-pencil"></i>
                            </div>
                          </div>

                          <div class="col-12">
                            <button type="submit" class="btn filled-btn"><?php echo e(__('Submit')); ?></button>
                          </div>
                        </div>
                      </form>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </div>

          <?php
            $position = $currencyInfo->base_currency_symbol_position;
            $symbol = $currencyInfo->base_currency_symbol;
          ?>

          <div class="col-lg-4">
            <div class="packages-sidebar">
              <div class="widget information-widget">
                <h4 class="widget-title"><?php echo e(__('Information')); ?></h4>
                <ul class="list">
                  <?php if($details->package->pricing_type == 'negotiable'): ?>
                    <li><strong><?php echo e(__('Price')); ?></strong>: <?php echo e(__(strtoupper($details->package->pricing_type))); ?>

                    </li>
                  <?php else: ?>
                    <li><strong><?php echo e(__('Price')); ?></strong> :
                      <?php echo e($position == 'left' ? $symbol : ''); ?><?php echo e($details->package->package_price); ?><?php echo e($position == 'right' ? $symbol : ''); ?>

                      <?php echo e('(' . __(strtoupper($details->package->pricing_type)) . ')'); ?></li>
                  <?php endif; ?>
                  <li><strong><?php echo e(__('Number of Days')); ?></strong> : <?php echo e($details->package->number_of_days); ?></li>
                  <li><strong><?php echo e(__('Maximum Persons')); ?></strong> :
                    <?php echo e($details->package->max_persons != null ? $details->package->max_persons : '-'); ?></li>
                </ul>
                <?php if($packageRating->package_rating_status == 1): ?>
                  <div class="rate">
                    <div class="rating" style="width:<?php echo e($avgRating * 20); ?>%"></div>
                  </div>
                <?php endif; ?>
              </div>

              <div
                class="widget booking-widget <?php echo e($details->package->pricing_type == 'negotiable' ? 'd-none' : ''); ?>">
                <h4 class="widget-title"><?php echo e(__('Book Package')); ?></h4>

                <?php if(Auth::guard('web')->check() == false && $status->package_guest_checkout_status == 1): ?>
                  <div class="alert alert-warning">
                    <?php echo e(__('You are now booking as a guest. if you want to log in before booking, then please')); ?> <a
                      href="<?php echo e(route('user.login', ['redirectPath' => 'package_details'])); ?>"><?php echo e(__('Click Here')); ?></a>
                  </div>
                <?php endif; ?>

                <form action="<?php echo e(route('package_booking')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="package_id" value="<?php echo e($details->package_id); ?>">

                  <div class="form_group">
                    <?php if(auth()->guard('web')->guest()): ?>
                      <input type="text" placeholder="<?php echo e(__('Full Name')); ?>" name="customer_name"
                        value="<?php echo e(old('customer_name')); ?>">
                    <?php endif; ?>

                    <?php if(auth()->guard('web')->check()): ?>
                      <?php
                        if (!empty(Auth::guard('web')->user()->first_name) || !empty(Auth::guard('web')->user()->last_name)) {
                            $fname = Auth::guard('web')->user()->first_name . ' ' . Auth::guard('web')->user()->last_name;
                        } else {
                            $fname = '';
                        }
                      ?>
                      <input type="text" placeholder="<?php echo e(__('Full Name')); ?>" name="customer_name"
                        value="<?php echo e($fname); ?>">
                    <?php endif; ?>
                    <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mt-2 ml-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form_group">
                    <?php if(auth()->guard('web')->guest()): ?>
                      <input type="text" placeholder="<?php echo e(__('Phone Number')); ?>" name="customer_phone"
                        value="<?php echo e(old('customer_phone')); ?>">
                    <?php endif; ?>

                    <?php if(auth()->guard('web')->check()): ?>
                      <input type="text" placeholder="<?php echo e(__('Phone Number')); ?>" name="customer_phone"
                        value="<?php echo e(Auth::guard('web')->user()->contact_number); ?>">
                    <?php endif; ?>
                    <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mt-2 ml-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form_group">
                    <?php if(auth()->guard('web')->guest()): ?>
                      <input type="email" placeholder="<?php echo e(__('Email Address')); ?>" name="customer_email"
                        value="<?php echo e(old('customer_email')); ?>">
                    <?php endif; ?>

                    <?php if(auth()->guard('web')->check()): ?>
                      <input type="email" placeholder="<?php echo e(__('Email Address')); ?>" name="customer_email"
                        value="<?php echo e(Auth::guard('web')->user()->email); ?>">
                    <?php endif; ?>
                    <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mt-2 ml-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form_group">
                    <input type="text" placeholder="<?php echo e(__('Number of Visitors')); ?>" name="visitors"
                      value="<?php echo e(old('visitors')); ?>">
                    <?php $__errorArgs = ['visitors'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mt-2 ml-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form_group h-50">
                    <select name="paymentType" id="payment-gateways" class="nice-select">
                      <option selected value="none">
                        <?php echo e(__('Select Payment Gateway')); ?>

                      </option>
                      <?php $__currentLoopData = $onlineGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onlineGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($onlineGateway->keyword); ?>">
                          <?php echo e($onlineGateway->name); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      <?php if(!empty($offlineGateways)): ?>
                        <?php $__currentLoopData = $offlineGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offlineGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($offlineGateway['id']); ?>">
                            <?php echo e($offlineGateway['name']); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </select>
                  </div>

                  <div class="row d-none" id="tab-stripe">
                    <div class="col-12 mb-3">
                      <div class="field-input">
                        <input type="text" class="card-elements" name="card_number"
                          placeholder="<?php echo e(__('Card Number')); ?>" autocomplete="off"
                          value="<?php echo e(old('card_number')); ?>" />
                      </div>
                      <?php $__errorArgs = ['card_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mt-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 mb-3">
                      <div class="field-input">
                        <input type="text" class="card-elements" placeholder="<?php echo e(__('CVC Number')); ?>"
                          name="cvc_number" value="<?php echo e(old('cvc_number')); ?>">
                      </div>
                      <?php $__errorArgs = ['cvc_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mt-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 mb-3">
                      <div class="field-input">
                        <input type="text" class="card-elements" placeholder="<?php echo e(__('Expiry Month')); ?>"
                          name="expiry_month" value="<?php echo e(old('expiry_month')); ?>">
                      </div>
                      <?php $__errorArgs = ['expiry_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mt-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 mb-4">
                      <div class="field-input">
                        <input type="text" class="card-elements mb-0" placeholder="<?php echo e(__('Expiry Year')); ?>"
                          name="expiry_year" value="<?php echo e(old('expiry_year')); ?>">
                      </div>
                      <?php $__errorArgs = ['expiry_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mt-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="d-none my-3 px-2" id="gateway-description"></div>

                  <div class="d-none mb-3 px-2" id="gateway-instruction"></div>

                  <div class="d-none mb-4 pl-2" id="gateway-attachment">
                    <input type="file" name="attachment">
                  </div>

                  <div class="mb-2">
                    <div class="d-flex">
                      <input type="text" id="coupon-code" placeholder="<?php echo e(__('Enter Your Coupon')); ?>">
                      <button type="button" class="btn filled-btn" onclick="applyCoupon(event)"
                        style="padding: 0px 15px;">
                        <?php echo e(__('Apply')); ?>

                      </button>
                    </div>
                  </div>

                  <div class="price-option-table mt-4">
                    <ul>
                      <li class="single-price-option">
                        <span class="title"><?php echo e(__('Subtotal')); ?> <span
                            class="amount"><?php echo e($position == 'left' ? $symbol : ''); ?><span
                              id="subtotal-amount"><?php echo e($details->package->package_price); ?></span><?php echo e($position == 'right' ? $symbol : ''); ?></span></span>
                      </li>

                      <li class="single-price-option">
                        <span class="title"><?php echo e(__('Discount')); ?> <span class="text-success">(<i
                              class="fas fa-minus"></i>)</span>
                          <span class="amount"><?php echo e($position == 'left' ? $symbol : ''); ?><span
                              id="discount-amount">0.00</span><?php echo e($position == 'right' ? $symbol : ''); ?></span>
                        </span>
                      </li>

                      <li class="single-price-option">
                        <span class="title"><?php echo e(__('Total')); ?> <span
                            class="amount"><?php echo e($position == 'left' ? $symbol : ''); ?><span
                              id="total-amount"><?php echo e($details->package->package_price); ?></span><?php echo e($position == 'right' ? $symbol : ''); ?></span></span>
                      </li>
                    </ul>
                  </div>

                  <div class="form_group mt-4">
                    <button class="btn filled-btn d-inline-block"><?php echo e(__('Book Now')); ?></button>
                  </div>
                </form>
              </div>

              <?php if(!is_null($details->package->email) || !is_null($details->package->phone)): ?>
                <div class="widget information-widget">
                  <h4 class="widget-title"><?php echo e(__('Help & Support')); ?></h4>
                  <ul class="list">
                    <?php if(!is_null($details->package->phone)): ?>
                      <li><strong><?php echo e(__('Phone')); ?></strong>: <?php echo e($details->package->phone); ?></li>
                    <?php endif; ?>
                    <?php if(!is_null($details->package->email)): ?>
                      <li><strong><?php echo e(__('Email')); ?></strong>: <?php echo e($details->package->email); ?></li>
                    <?php endif; ?>
                  </ul>
                </div>
              <?php endif; ?>

              <div class="widget share-widget">
                <h4 class="widget-title"><?php echo e(__('Share This Package')); ?></h4>
                <ul class="social-icons">
                  <li><a href="//www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>"
                      class="facebook"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a
                      href="//twitter.com/intent/tweet?text=my share text&amp;url=<?php echo e(urlencode(url()->current())); ?>"
                      class="twitter"><i class="fab fa-twitter"></i></a></li>
                  <li><a
                      href="//www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo e(urlencode(url()->current())); ?>&amp;title=<?php echo e(convertUtf8($details->title)); ?>"
                      class="linkedin"><i class="fab fa-linkedin-in"></i></a></li>
                  <li><a href="//plus.google.com/share?url=<?php echo e(urlencode(url()->current())); ?>" class="google"><i
                        class="fab fa-google"></i></a></li>
                </ul>
              </div>

              <div class="widget latest-package-widget">
                <h4 class="widget-title"><?php echo e(__('Related Packages')); ?></h4>

                <?php $__currentLoopData = $latestPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestPackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="packages-item">
                    <div class="post-thumbnail">
                      <img class="lazy"
                        data-src="<?php echo e(asset('assets/img/packages/' . $latestPackage->package->featured_img)); ?>"
                        alt="image">
                    </div>

                    <div class="entry-content">
                      <h3 class="title"><a
                          href="#"><?php echo e(strlen($latestPackage->title) > 30 ? mb_substr($latestPackage->title, 0, 30, 'UTF-8') . '...' : $latestPackage->title); ?></a>
                      </h3>
                      <p>
                        <?php echo e(strlen(strip_tags($latestPackage->description)) > 50 ? substr(strip_tags($latestPackage->description), 0, 50) . '...' : strip_tags($latestPackage->description)); ?>

                      </p>
                      <a href="<?php echo e(route('package_details', ['id' => $latestPackage->package_id, 'slug' => $latestPackage->slug])); ?>"
                        class="btn"><?php echo e(__('view package')); ?></a>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script>
    "use strict";
    var offlineGateways = <?php echo json_encode($offlineGateways); ?>;
    var pricingType = '<?php echo e($details->package->pricing_type); ?>';
    var initialPrice = '<?php echo e($details->package->package_price); ?>';
  </script>

  <script src="<?php echo e(asset('assets/js/package-details.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/packages/package_details.blade.php ENDPATH**/ ?>