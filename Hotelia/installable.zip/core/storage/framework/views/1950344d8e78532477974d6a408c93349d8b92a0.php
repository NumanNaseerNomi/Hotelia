<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Saved QR Codes')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('QR Codes')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Saved QR Codes')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="card-title d-inline-block"><?php echo e(__('QR Codes')); ?></div>
          <button class="btn btn-danger float-right btn-sm mr-2 d-none bulk-delete" data-href="<?php echo e(route('admin.qrcode.bulk.delete')); ?>">
            <i class="flaticon-interface-5"></i> <?php echo e(__('Delete')); ?>

          </button>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <?php if(count($qrcodes) == 0): ?>
                <h3 class="text-center"><?php echo e(__('NO QR CODE FOUND')); ?></h3>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-striped mt-3" id="basic-datatables">
                    <thead>
                      <tr>
                        <th scope="col">
                          <input type="checkbox" class="bulk-check" data-val="all">
                        </th>
                        <th scope="col"><?php echo e(__('Name')); ?></th>
                        <th scope="col"><?php echo e(__('URL')); ?></th>
                        <th scope="col"><?php echo e(__('Qr Code')); ?></th>
                        <th scope="col"><?php echo e(__('Actions')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $qrcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $qrcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <input type="checkbox" class="bulk-check" data-val="<?php echo e($qrcode->id); ?>">
                          </td>
                          <td>
                            <?php echo e($qrcode->name); ?>

                          </td>
                          <td>
                            <?php echo e($qrcode->url); ?>

                          </td>
                          <td>
                            <button class="btn btn-primary" data-toggle="modal" data-target="#qrModal<?php echo e($qrcode->id); ?>">
                              <i class="far fa-eye"></i>
                              <?php echo e(__('Show')); ?>

                            </button>
                          </td>
                          <td>
                            <a href="<?php echo e(asset('assets/img/qr/' . $qrcode->image)); ?>" download="<?php echo e($qrcode->name); ?>.png" class="btn btn-secondary btn-sm">
                              <i class="fas fa-download"></i> <?php echo e(__('Download')); ?>

                            </a>
                            <form class="deleteform d-inline-block" action="<?php echo e(route('admin.qrcode.delete')); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="qrcode_id" value="<?php echo e($qrcode->id); ?>">
                              <button type="submit" class="btn btn-danger btn-sm deletebtn">
                                <span class="btn-label">
                                  <i class="fas fa-trash"></i>
                                </span>
                                <?php echo e(__('Delete')); ?>

                              </button>
                            </form>
                          </td>
                        </tr>

                        <!-- Modal -->
                        <div class="modal fade" id="qrModal<?php echo e($qrcode->id); ?>" tabindex="-1" role="dialog" aria-labelledby="qrModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="urlsModalLabel"><?php echo e(__('QR Code')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>

                              <div class="modal-body text-center">
                                <div class="p-5 bg-white">
                                  <img src="<?php echo e(asset('assets/img/qr/' . $qrcode->image)); ?>" alt="">
                                </div>
                              </div>

                              <div class="modal-footer justify-content-center">
                                <a href="<?php echo e(asset('assets/img/qr/' . $qrcode->image)); ?>" download="<?php echo e($qrcode->name); ?>.png" class="btn btn-secondary">
                                  <i class="fas fa-download"></i> <?php echo e(__('Download')); ?>

                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/qr/index.blade.php ENDPATH**/ ?>