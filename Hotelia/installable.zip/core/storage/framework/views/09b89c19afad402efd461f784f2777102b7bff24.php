<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Login')); ?>

<?php $__env->stopSection(); ?>

<?php
    $metaKeys = !empty($seo->meta_keyword_login) ? $seo->meta_keyword_login : '';
    $metaDesc = !empty($seo->meta_description_login) ? $seo->meta_description_login : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(__('Login')); ?></h1>
          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>
            <li><?php echo e(__('Login')); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Area Start -->
    <div class="user-area-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <?php if($basicInfo->facebook_login_status == 1 || $basicInfo->google_login_status == 1): ?>
            <div class="social-logins my-4">
              <div class="btn-group btn-group-toggle d-flex">
                <?php if($basicInfo->facebook_login_status == 1): ?>
                <a class="btn py-2 facebook-login-btn" href="<?php echo e(route('user.facebook_login')); ?>">
                  <i class="fab fa-facebook-f <?php echo e($currentLanguageInfo->direction == 0 ? 'mr-2' : 'ml-2'); ?>"></i> <?php echo e(__('Login via Facebook')); ?>

                </a>
                <?php endif; ?>

                <?php if($basicInfo->google_login_status == 1): ?>
                <a class="btn py-2 google-login-btn" href="<?php echo e(route('user.google_login')); ?>">
                  <i class="fab fa-google <?php echo e($currentLanguageInfo->direction == 0 ? 'mr-2' : 'ml-2'); ?>"></i> <?php echo e(__('Login via Google')); ?>

                </a>
                <?php endif; ?>
              </div>
            </div>
            <?php endif; ?>

            <div class="user-content">
              <form action="<?php echo e(route('user.login_submit')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="input-box">
                  <label><?php echo e(__('Email Address') . '*'); ?></label>
                  <input type="email" name="email" value="<?php echo e(old('email')); ?>">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-3 ml-2 text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="input-box">
                  <label><?php echo e(__('Password') . '*'); ?></label>
                  <input type="password" name="password" value="<?php echo e(old('password')); ?>">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-3 ml-2 text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <?php if($websiteInfo->google_recaptcha_status == 1): ?>
                    <div class="d-block mb-4">
                        <?php echo NoCaptcha::renderJs(); ?>

                        <?php echo NoCaptcha::display(); ?>

                        <?php if($errors->has('g-recaptcha-response')): ?>
                        <?php
                            $errmsg = $errors->first('g-recaptcha-response');
                        ?>
                        <p class="text-danger mb-0 mt-2"><?php echo e(__("$errmsg")); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="input-box">
                  <button type="submit" class="btn"><?php echo e(__('Log In')); ?></button>
                  <a href="<?php echo e(route('user.forget_password')); ?>"><?php echo e(__('Lost your password?')); ?></a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Login Area End -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/user/login.blade.php ENDPATH**/ ?>