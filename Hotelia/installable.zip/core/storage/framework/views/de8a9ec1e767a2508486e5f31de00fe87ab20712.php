<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Rooms')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Rooms Management')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Rooms')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-4">
              <div class="card-title d-inline-block"><?php echo e(__('Rooms')); ?></div>
            </div>

            <div class="col-lg-4 offset-lg-4 mt-2 mt-lg-0">
              <a
                href="<?php echo e(route('admin.rooms_management.create_room')); ?>"
                class="btn btn-primary btn-sm float-right"
              ><i class="fas fa-plus"></i> <?php echo e(__('Add Room')); ?></a>

              <button
                class="btn btn-danger btn-sm float-right mr-2 d-none bulk-delete"
                data-href="<?php echo e(route('admin.rooms_management.bulk_delete_room')); ?>"
              ><i class="flaticon-interface-5"></i> <?php echo e(__('Delete')); ?></button>
            </div>
          </div>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <?php if(count($roomContents) == 0): ?>
                <h3 class="text-center"><?php echo e(__('NO ROOM FOUND!')); ?></h3>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-striped mt-3" id="basic-datatables">
                    <thead>
                      <tr>
                        <th scope="col">
                          <input type="checkbox" class="bulk-check" data-val="all">
                        </th>
                        <th scope="col"><?php echo e(__('Title')); ?></th>
                        <?php if($websiteInfo->room_category_status == 1): ?>
                          <th scope="col"><?php echo e(__('Category')); ?></th>
                        <?php endif; ?>
                        <th scope="col"><?php echo e(__('Featured')); ?></th>
                        <th scope="col"><?php echo e(__('Rent')); ?></th>
                        <th scope="col"><?php echo e(__('Actions')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $roomContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <input type="checkbox" class="bulk-check" data-val="<?php echo e($roomContent->room_id); ?>">
                          </td>
                          <td>
                            <?php echo e(strlen($roomContent->title) > 30 ? mb_substr($roomContent->title,0,30,'utf-8') . '...' : $roomContent->title); ?>

                          </td>
                          <?php if($websiteInfo->room_category_status == 1): ?>
                            <td><?php echo e($roomContent->roomCategory->name); ?></td>
                          <?php endif; ?>
                          <td>
                            <form
                              id="featureForm<?php echo e($roomContent->room_id); ?>"
                              class="d-inline-block"
                              action="<?php echo e(route('admin.rooms_management.update_featured_room')); ?>"
                              method="post"
                            >
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="roomId" value="<?php echo e($roomContent->room_id); ?>">

                              <select
                                class="form-control <?php echo e($roomContent->room->is_featured == 1 ? 'bg-success' : 'bg-danger'); ?>"
                                name="is_featured"
                                onchange="document.getElementById('featureForm<?php echo e($roomContent->room_id); ?>').submit();"
                              >
                                <option value="1" <?php echo e($roomContent->room->is_featured == 1 ? 'selected' : ''); ?>>
                                  <?php echo e(__('Yes')); ?>

                                </option>
                                <option value="0" <?php echo e($roomContent->room->is_featured == 0 ? 'selected' : ''); ?>>
                                  <?php echo e(__('No')); ?>

                                </option>
                              </select>
                            </form>
                          </td>
                          <td>
                            <?php echo e($currencyInfo->base_currency_symbol_position == 'left' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e($roomContent->room->rent); ?> <?php echo e($currencyInfo->base_currency_symbol_position == 'right' ? $currencyInfo->base_currency_symbol : ''); ?>

                          </td>
                          <td>
                            <a
                              class="btn btn-secondary btn-sm mr-1"
                              href="<?php echo e(route('admin.rooms_management.edit_room', $roomContent->room_id)); ?>"
                            >
                                <i class="fas fa-edit"></i>
                            </a>

                            <form
                              class="deleteForm d-inline-block"
                              action="<?php echo e(route('admin.rooms_management.delete_room')); ?>"
                              method="post"
                            >
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="room_id" value="<?php echo e($roomContent->room_id); ?>">

                              <button type="submit" class="btn btn-danger btn-sm deleteBtn">
                                  <i class="fas fa-trash"></i>
                              </button>
                            </form>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/rooms/rooms.blade.php ENDPATH**/ ?>