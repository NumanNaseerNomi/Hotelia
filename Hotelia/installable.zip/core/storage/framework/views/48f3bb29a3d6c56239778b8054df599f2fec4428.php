<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Home')); ?>

<?php $__env->stopSection(); ?>

<?php
    $metaKeywords = !empty($seo->meta_keyword_home) ? $seo->meta_keyword_home : '';
    $metaDescription = !empty($seo->meta_description_home) ? $seo->meta_description_home : '';
?>
<?php $__env->startSection('meta-keywords', "<?php echo e($metaKeywords); ?>"); ?>
<?php $__env->startSection('meta-description', "$metaDescription"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <?php
        if(!empty($hero)) {
            $img = $hero->img;
            $title = $hero->title;
            $subtitle = $hero->subtitle;
            $btnUrl = $hero->btn_url;
            $btnName = $hero->btn_name;
        } else {
            $img = '';
            $title = '';
            $subtitle = '';
            $btnUrl = '';
            $btnName = '';
        }
    ?>
    <?php if($websiteInfo->home_version == 'static'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme2.static')) echo $__env->make('frontend.partials.hero.theme2.static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'slider'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme2.slider')) echo $__env->make('frontend.partials.hero.theme2.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'video'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme2.video')) echo $__env->make('frontend.partials.hero.theme2.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'particles'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme2.particles')) echo $__env->make('frontend.partials.hero.theme2.particles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'water'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme2.water')) echo $__env->make('frontend.partials.hero.theme2.water', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'parallax'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme2.parallax')) echo $__env->make('frontend.partials.hero.theme2.parallax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($sections->search_section == 1): ?>
    <!-- Booking Search Form Start -->
    <section class="booking-section style-two primary-bg">
      <div class="container-fluid">
        <div class="row no-gutters justify-content-center">
          <div class="col-xl-10">
            <div class="booking-form-wrap">
              <form action="<?php echo e(route('rooms')); ?>" method="GET">
                <div class="bookIng-inner-wrap">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="input-wrap">
                              <input type="text" placeholder="<?php echo e(__('Check In / Out Date')); ?>" id="date-range" name="dates" readonly>
                              <i class="far fa-calendar-alt"></i>
                            </div>
                        </div>

                        <div class="col-lg-2">
                            <div class="input-wrap">
                              <select name="beds" class="nice-select">
                                <option selected disabled><?php echo e(__('Beds')); ?></option>

                                <?php for($i = 1; $i <= $numOfBed; $i++): ?>
                                  <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                              </select>
                            </div>
                        </div>

                        <div class="col-lg-2">
                          <div class="input-wrap">
                            <select name="baths" class="nice-select">
                              <option selected disabled><?php echo e(__('Baths')); ?></option>

                              <?php for($i = 1; $i <= $numOfBath; $i++): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                              <?php endfor; ?>
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-2">
                          <div class="input-wrap">
                            <select name="guests" class="nice-select">
                              <option selected disabled><?php echo e(__('Guests')); ?></option>

                              <?php for($i = 1; $i <= $numOfGuest; $i++): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                              <?php endfor; ?>
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3">
                          <div class="input-wrap">
                            <button type="submit" class="btn filled-btn btn-block btn-black">
                              <?php echo e(__('search')); ?> <i class="far fa-long-arrow-right"></i>
                            </button>
                          </div>
                        </div>
                    </div>
                </div>
              </form>

              <div class="booking-shape-1">
                <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/01.png')); ?>" alt="shape">
              </div>
              <div class="booking-shape-2">
                <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/06.png')); ?>" alt="shape">
              </div>
              <div class="booking-shape-3">
                <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/07.png')); ?>" alt="shape">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Booking Search Form End -->
    <?php endif; ?>


    <?php if($sections->featured_services_section == 1): ?>
    <!-- Feature Service Section Start -->
    <section class="feature-section section-padding">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <?php if(!empty($secHeading)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <span class="title-top"><?php echo e(convertUtf8($secHeading->service_section_title)); ?></span>
                    <h1><?php echo e(convertUtf8($secHeading->service_section_subtitle)); ?></h1>
                </div>
            </div>
          <?php endif; ?>
        </div>

        <!-- Single Service Box -->
        <?php if(count($serviceInfos) == 0 || $serviceFlag == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Featured Service Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $serviceInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(!empty($serviceInfo->service)): ?>
                <div class="col-lg-4 col-md-6">
                  <div
                    class="single-feature-box text-center wow fadeIn animated"
                    data-wow-duration="1500ms"
                    data-wow-delay="400ms"
                  >
                    <div class="feature-icon">
                      <i class="<?php echo e($serviceInfo->service->service_icon); ?>"></i>
                    </div>
                    <h4><?php echo e(convertUtf8($serviceInfo->title)); ?></h4>
                    <p><?php echo e($serviceInfo->summary); ?></p>
                    <?php if($serviceInfo->service->details_page_status == 1): ?>
                      <a href="<?php echo e(route('service_details', ['id' => $serviceInfo->service_id, 'slug' => $serviceInfo->slug])); ?>" class="read-more">
                        <?php echo e(__('read more')); ?> <i class="far fa-long-arrow-right"></i>
                      </a>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Feature Service Section Start -->
    <?php endif; ?>

    <?php if($sections->featured_rooms_section == 1): ?>
    <!-- Latest Room Section Start -->
    <section class="latest-room section-padding">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <?php if(!empty($secHeading)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <span class="title-top"><?php echo e($secHeading->room_section_title); ?></span>
                    <h1><?php echo e($secHeading->room_section_subtitle); ?></h1>
                </div>
            </div>
          <?php endif; ?>
        </div>

        <!-- Single Room Box -->
        <?php if(count($roomInfos) == 0 || $roomFlag == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Featured Room Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $roomInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(!empty($roomInfo->room)): ?>
                <div class="col-lg-4 col-md-6">
                  <div class="room-box text-center">
                    <div class="room-img">
                      <img class="lazy" data-src="<?php echo e(asset('assets/img/rooms/' . $roomInfo->room->featured_img)); ?>" alt="room">
                    </div>
                    <div class="room-content">
                      <i class="far fa-stars"></i>
                      <h5>
                        <a href="<?php echo e(route('room_details', ['id' => $roomInfo->room_id, 'slug' => $roomInfo->slug])); ?>"><?php echo e(strlen($roomInfo->title) > 25 ? mb_substr($roomInfo->title, 0, 25, 'utf-8') . '....' : $roomInfo->title); ?></a>
                      </h5>
                      <p class="price"><?php echo e($currencyInfo->base_currency_symbol_position == 'left' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e($roomInfo->room->rent); ?> <?php echo e($currencyInfo->base_currency_symbol_position == 'right' ? $currencyInfo->base_currency_symbol : ''); ?></p>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- Design Shape -->
      <div class="shape-one">
        <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/08.png')); ?>" alt="shape">
      </div>
      <div class="shape-two">
        <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/03.png')); ?>" alt="shape">
      </div>
      <div class="shape-three"></div>
    </section>
    <!-- Latest Room Section End -->
    <?php endif; ?>


    <?php if($sections->featured_package_section == 1): ?>
    <!-- Package Section Start -->
    <section class="ma-package-section section-padding featured-packages">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <?php if(!empty($secHeading)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <span class="title-top"><?php echo e(convertUtf8($secHeading->package_section_title)); ?></span>
                    <h1><?php echo e(convertUtf8($secHeading->package_section_subtitle)); ?></h1>
                </div>
            </div>
          <?php endif; ?>
        </div>

        <!-- Package Boxes -->
        <?php if(count($packageInfos) == 0 || $packageFlag == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Featured Package Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $packageInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(!empty($packageInfo->package)): ?>
                <div class="col-lg-6">
                  <div class="packages-post-item">
                    <a class="post-thumbnail d-block" href="<?php echo e(route('package_details', ['id' => $packageInfo->package_id, 'slug' => $packageInfo->slug])); ?>">
                      <img class="lazy" data-src="<?php echo e(asset('assets/img/packages/' . $packageInfo->package->featured_img)); ?>" alt="package img">
                    </a>

                    <div class="entry-content">
                      <h3 class="title">
                        <a href="<?php echo e(route('package_details', ['id' => $packageInfo->package_id, 'slug' => $packageInfo->slug])); ?>"><?php echo e(strlen($packageInfo->title) > 50 ? mb_substr($packageInfo->title, 0, 50, 'utf-8') . '...' : $packageInfo->title); ?></a>
                      </h3>
                      <div class="post-meta">
                        <ul>

                          <?php if($packageInfo->package->pricing_type != 'negotiable'): ?>
                            <li><span><i class="fas fa-comment-dollar"></i><strong><?php echo e(__('Package Price' . ':')); ?></strong> <?php echo e($currencyInfo->base_currency_symbol_position == 'left' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e($packageInfo->package->package_price); ?> <?php echo e($currencyInfo->base_currency_symbol_position == 'right' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e('(' . strtoupper($packageInfo->package->pricing_type) . ')'); ?></span></li>
                          <?php else: ?>
                            <li><span><i class="fas fa-comment-dollar"></i><strong><?php echo e(__('Package Price' . ':')); ?></strong> <?php echo e(__('Negotiable')); ?></span></li>
                          <?php endif; ?>

                          <li><span><i class="fas fa-users"></i><strong><?php echo e(__('Number of Days' . ':')); ?></strong> <?php echo e($packageInfo->package->number_of_days); ?></span></li>

                          <li><span><i class="fas fa-users"></i><strong><?php echo e(__('Maximum Persons' . ':')); ?></strong> <?php echo e($packageInfo->package->max_persons != null ? $packageInfo->package->max_persons : '-'); ?></span></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Package Section End -->
    <?php endif; ?>


    <section class="feature-section-two">
        <?php if($sections->faq_section == 1): ?>
        <!-- Why Choose US/FAQ Start -->
        <div class="wcu-section">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-6">
                <!-- Section Title -->
                <div class="section-title">
                  <?php if(!empty($secHeading)): ?>
                    <span class="title-top"><?php echo e(convertUtf8($secHeading->faq_section_title)); ?></span>
                    <h1><?php echo e(convertUtf8($secHeading->faq_section_subtitle)); ?></h1>
                  <?php endif; ?>
                </div>

                <?php if(count($faqs) > 0): ?>
                  <div class="feature-accordion accordion" id="faqAccordion">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="card">
                        <div class="card-header ">
                          <button
                            type="button"
                            class="<?php echo e($loop->first ? 'active-accordion' : ''); ?>"
                            data-toggle="collapse"
                            data-target="<?php echo e('#faq' . $faq->id); ?>"
                          >
                            <?php echo e($faq->question); ?>

                            <span class="open-icon"><i class="far fa-eye-slash"></i></span>
                            <span class="close-icon"><i class="far fa-eye"></i></span>
                          </button>
                        </div>

                        <div
                          id="<?php echo e('faq' . $faq->id); ?>"
                          class="collapse <?php echo e($loop->first ? 'show' : ''); ?>"
                          data-parent="#faqAccordion"
                        >
                          <div class="card-body"><?php echo e($faq->answer); ?></div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <?php endif; ?>
              </div>

              <div class="col-lg-6">
                <div class="feature-accordion-img text-right">
                  <?php if(!empty($secHeading->faq_section_image)): ?>
                    <img class="lazy" data-src="<?php echo e(asset('assets/img/faq_section/' . $secHeading->faq_section_image)); ?>" alt="image">
                  <?php endif; ?>

                  <div class="degin-shape">
                    <div class="shape-one">
                      <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/11.png')); ?>" alt="shape">
                    </div>
                    <div class="shape-two">
                      <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/12.png')); ?>" alt="shape">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Why Choose US/FAQ End -->
        <?php endif; ?>

        <?php if($sections->intro_section == 1): ?>
        <!-- Intro Section Start -->
        <div class="featured-slider position-relative section-padding">
          <div class="container-fluid">
            <div class="row no-gutters">
              <div class="col-xl-10">
                <div class="feature-slide-wrap" id="featureSlideActive">
                  <div class="single-feature-slide">
                    <?php if(!empty($intro)): ?>
                      <img class="lazy f-big-image" data-src="<?php echo e(asset('assets/img/intro_section/' . $intro->intro_img)); ?>" alt="Image">
                    <?php endif; ?>

                    <div class="row no-gutters justify-content-end">
                      <div class="col-xl-5 col-lg-8 col-md-8">
                        <div class="f-desc">
                          <h1><?php echo e(!empty($intro->intro_secondary_title) ? $intro->intro_secondary_title : ''); ?></h1>
                          <p><?php echo e(!empty($intro->intro_text) ? $intro->intro_text : ''); ?></p>
                          <div class="line"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Intro Section End -->
        <?php endif; ?>
    </section>

    <?php if($sections->statistics_section == 1): ?>
    <!-- CounterUp Start -->
    <section
      class="counter-up primary-bg lazy"
      data-bg="<?php echo e(asset('assets/img/counter-bg.jpg')); ?>"
    >
      <div class="container">
        <?php if(count($counterInfos) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Counter Information Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $counterInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counterInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-3 col-md-6">
                <div class="counter-box style-two">
                  <div class="fact-icon">
                    <i class="<?php echo e($counterInfo->icon); ?>"></i>
                  </div>
                  <p class="fact-num"><span class="counter-number"><?php echo e($counterInfo->amount); ?></span></p>
                  <p><?php echo e($counterInfo->title); ?></p>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- CounterUp End -->
    <?php endif; ?>

    <?php if($sections->video_section == 1): ?>
    <!-- Call To Action Start -->
    <section class="cta-section bg-img-center lazy <?php echo e($websiteInfo->home_version == 'parallax' ? 'parallax' : ''); ?>" data-bg="<?php echo e(asset('assets/img/booking-img.jpg')); ?>">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-10">
            <div class="cta-left-content">
              <?php if(!empty($secHeading)): ?>
                <span><?php echo e(convertUtf8($secHeading->booking_section_title)); ?></span>
                <h1><?php echo e(convertUtf8($secHeading->booking_section_subtitle)); ?></h1>
                <a href="<?php echo e($secHeading->booking_section_button_url); ?>" class="btn filled-btn">
                  <?php echo e($secHeading->booking_section_button); ?> <i class="far fa-long-arrow-right"></i>
                </a>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-md-2">
            <?php if(!empty($secHeading)): ?>
              <div class="video-icon text-right">
                <a href="<?php echo e($secHeading->booking_section_video_url); ?>" class="video-popup"> <i class="fas fa-play"></i></a>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>
    <!-- Call To Action End -->
    <?php endif; ?>

    <?php if($sections->testimonials_section == 1): ?>
    <!-- Feedback/Testimonial Section Start -->
    <section class="feedback-section-two section-padding">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <?php if(!empty($secHeading)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <span class="title-top"><?php echo e($secHeading->testimonial_section_title); ?></span>
                    <h1><?php echo e($secHeading->testimonial_section_subtitle); ?></h1>
                </div>
            </div>
          <?php endif; ?>
        </div>

        <?php if(count($testimonials) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Testimonial Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="feedback-slider-two" id="feedSliderTwo">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <div class="single-feedback-slide">
                  <div class="row align-items-center">
                    <div class="col-lg-6">
                      <div class="client-big-img">
                        <?php if(!empty($secHeading->testimonial_section_image)): ?>
                          <img class="lazy" data-src="<?php echo e(asset('assets/img/testimonial_section/' . $secHeading->testimonial_section_image)); ?>" alt="">
                        <?php endif; ?>
                      </div>
                    </div>

                    <div class="col-lg-5 offset-lg-1">
                      <div class="feedback-desc">
                        <div class="feedback-client-desc d-flex align-items-center">
                          <?php if(!empty($testimonial->client_image)): ?>
                            <div class="client-img">
                                <img class="lazy" data-src="<?php echo e(asset('assets/img/testimonial_section/' . $testimonial->client_image)); ?>" alt="">
                            </div>
                          <?php endif; ?>
                          <div class="client-name">
                            <h3><?php echo e(convertUtf8($testimonial->client_name)); ?></h3>
                            <?php if(!empty($testimonial->client_designation)): ?>
                            <span class="client-job"><?php echo e(convertUtf8($testimonial->client_designation)); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <p><?php echo e($testimonial->comment); ?></p>
                        <span class="quote-icon"><img class="lazy" data-src="<?php echo e(asset('assets/img/icons/quote.png')); ?>" alt="quote"></span>
                      </div>
                    </div>
                  </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Feedback/Testimonial Section End -->
    <?php endif; ?>

    <?php if($sections->blogs_section == 1): ?>
    <!-- Latest Blog Start -->
    <section class="latest-blog section-padding section-bg">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <?php if(!empty($secHeading)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <span class="title-top"><?php echo e(convertUtf8($secHeading->blog_section_title)); ?></span>
                    <h1><?php echo e(convertUtf8($secHeading->blog_section_subtitle)); ?></h1>
                </div>
            </div>
          <?php endif; ?>
        </div>

        <?php if(count($blogInfos) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Latest Blog Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $blogInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-6 col-sm-6 order-lg-1 order-sm-2">
                <div
                  class="single-latest-blog wow <?php if($loop->iteration == 1): ?> fadeIn
                  <?php elseif($loop->iteration == 2): ?> fadeInUp
                  <?php elseif($loop->iteration == 3): ?> fadeIn <?php endif; ?> animated"
                  data-wow-duration="1500ms"
                  data-wow-delay="<?php if($loop->iteration == 1): ?> 400ms
                  <?php elseif($loop->iteration == 2): ?> 600ms
                  <?php elseif($loop->iteration == 3): ?> 800ms <?php endif; ?>"
                >
                  <div class="blog-img">
                    <img class="lazy" data-src="<?php echo e(asset('assets/img/blogs/' . $blogInfo->blog->blog_img)); ?>" alt="blog image">
                  </div>
                  <div class="latest-blog-desc">
                    <span class="post-date"><i class="far fa-calendar-alt"></i><?php echo e(date_format($blogInfo->blog->created_at, 'd M Y')); ?></span>
                    <h6>
                      <?php echo e(convertUtf8($blogInfo->title)); ?>

                    </h6>
                    <a href="<?php echo e(route('blog_details', ['id' => $blogInfo->blog_id, 'slug' => $blogInfo->slug])); ?>" class="read-more">
                      <?php echo e(__('read more')); ?> <i class="far fa-long-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Latest Blog End -->
    <?php endif; ?>

    <?php if($sections->brand_section == 1): ?>
    <!-- Brands Section Start -->
    <section class="brands-section primary-bg">
      <div class="container">
        <?php if(count($brands) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Brand Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div id="brandsSlideActive" class="row">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="brand-item text-center d-block" href="<?php echo e($brand->brand_url); ?>" target="_blank">
                  <img class="lazy" data-src="<?php echo e(asset('assets/img/brands/' . $brand->brand_img)); ?>" alt="brand image">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Brands Section End -->
    <?php endif; ?>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script src="<?php echo e(asset('assets/js/home.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/home/index_two.blade.php ENDPATH**/ ?>