<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Room Details')); ?>

<?php $__env->stopSection(); ?>

<?php
  $metaKeys = !empty($details->meta_keywords) ? $details->meta_keywords : '';
  $metaDesc = !empty($details->meta_description) ? $details->meta_description : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(strlen($details->title) > 30 ? mb_substr($details->title, 0, 30, 'utf-8') . '...' : $details->title); ?></h1>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>
            <li><?php echo e(__('Room Details')); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <section class="room-details-wrapper section-padding">
      <?php
        $position = $currencyInfo->base_currency_symbol_position;
        $symbol = $currencyInfo->base_currency_symbol;
      ?>

      <div class="container">
        
        <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="row">
            <div class="col">
              <div class="alert alert-danger alert-block">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="close" data-dismiss="alert">×</button>
              </div>
            </div>
          </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="row">
            <div class="col">
              <div class="alert alert-danger alert-block">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="close" data-dismiss="alert">×</button>
              </div>
            </div>
          </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="row">
          <!-- Room Details Section Start -->
          <div class="col-lg-8">
            <div class="room-details">
              <div class="entry-header">
                <div class="post-thumb position-relative">
                  <div class="post-thumb-slider">
                    <?php
                      $sliderImages = json_decode($details->room->slider_imgs);
                    ?>

                    <div class="main-slider">
                      <?php $__currentLoopData = $sliderImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-img">
                          <a href="<?php echo e(asset('assets/img/rooms/slider_images/' . $image)); ?>" class="main-img">
                            <img src="<?php echo e(asset('assets/img/rooms/slider_images/' . $image)); ?>" alt="Image">
                          </a>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="dots-slider row">
                      <?php $__currentLoopData = $sliderImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-dots">
                          <img src="<?php echo e(asset('assets/img/rooms/slider_images/' . $image)); ?>" alt="image">
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                  <div class="price-tag">
                    <?php echo e($position == 'left' ? $symbol : ''); ?><?php echo e($details->room->rent); ?><?php echo e($position == 'right' ? $symbol : ''); ?> / <?php echo e(__('Night')); ?>

                  </div>
                </div>

                <div class="d-flex align-items-center justify-content-between mb-4">
                    <?php if($websiteInfo->room_category_status == 1): ?>
                      <div class="room-cat mb-0">
                        <a href="<?php echo e(route('rooms', ['category' => $details->roomCategory->id])); ?>"><?php echo e($details->roomCategory->name); ?></a>
                      </div>
                    <?php endif; ?>

                    <?php if($status->room_rating_status == 1): ?>
                      <div class="rate">
                        <div class="rating" style="width:<?php echo e($avgRating * 20); ?>%"></div>
                      </div>
                    <?php endif; ?>
                </div>

                <p id="room-id" class="d-none"><?php echo e($details->room_id); ?></p>

                <h2 class="entry-title"><?php echo e(convertUtf8($details->title)); ?></h2>
                <ul class="entry-meta list-inline">
                  <li><i class="far fa-bed"></i><?php echo e($details->room->bed); ?> <?php echo e($details->room->bed == 1 ? __('Bed') : __('Beds')); ?></li>
                  <li><i class="far fa-bath"></i><?php echo e($details->room->bath); ?> <?php echo e($details->room->bath == 1 ? __('Bath') : __('Baths')); ?></li>
                  <?php if(!empty($details->room->max_guests)): ?>
                    <li><i class="far fa-users"></i><?php echo e($details->room->max_guests); ?> <?php echo e($details->room->max_guests == 1 ? __('Guest') : __('Guests')); ?></li>
                  <?php endif; ?>
                </ul>
              </div>

              <div class="room-details-tab">
                <div class="row">
                  <div class="col-sm-3">
                    <ul class="nav desc-tab-item" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" href="#desc" role="tab" data-toggle="tab">
                          <?php echo e(__('Room Details')); ?>

                        </a>
                      </li>

                      <li class="nav-item">
                        <a class="nav-link" href="#amm" role="tab" data-toggle="tab">
                          <?php echo e(__('Amenities')); ?>

                        </a>
                      </li>

                      <li class="nav-item">
                        <a class="nav-link" href="#location" role="tab" data-toggle="tab">
                          <?php echo e(__('Contact Info')); ?>

                        </a>
                      </li>

                      <li class="nav-item <?php echo e($status->room_rating_status == 0 ? 'd-none' : ''); ?>">
                        <a class="nav-link" href="#reviews" role="tab" data-toggle="tab">
                          <?php echo e(__('Reviews')); ?>

                        </a>
                      </li>
                    </ul>
                  </div>

                  <div class="col-sm-9">
                    <div class="tab-content desc-tab-content">
                      <div role="tabpanel" class="tab-pane fade in active show" id="desc">
                        <h5 class="tab-title"><?php echo e(__('Room Details')); ?></h5>
                        <div class="entry-content">
                          <p><?php echo replaceBaseUrl($details->description, 'summernote'); ?></p>
                        </div>
                      </div>

                      <div role="tabpanel" class="tab-pane fade" id="amm">
                        <h5 class="tab-title"><?php echo e(__('Amenities')); ?></h5>
                        <div class="ammenities">
                          <?php $__currentLoopData = $amms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $amm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a><?php echo e($amm); ?></a>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </div>

                      <div role="tabpanel" class="tab-pane fade" id="location">
                        <div class="room-location">
                          <div class="row">
                            <?php if(!empty($details->address)): ?>
                              <div class="col-4">
                                <h6><?php echo e(__('Address')); ?></h6>
                                <p><?php echo e($details->address); ?></p>
                              </div>
                            <?php endif; ?>

                            <?php if(!empty($details->phone)): ?>
                              <div class="col-4">
                                <h6><?php echo e(__('Phone')); ?></h6>
                                <p><?php echo e($details->phone); ?></p>
                              </div>
                            <?php endif; ?>

                            <?php if(!empty($details->email)): ?>
                              <div class="col-4">
                                <h6><?php echo e(__('Email')); ?></h6>
                                <p><?php echo e($details->email); ?></p>
                              </div>
                            <?php endif; ?>
                          </div>
                        </div>

                        <?php if(!empty($details->latitude) && !empty($details->longitude)): ?>
                          <h5 class="tab-title mt-3"><?php echo e(__('Google Map')); ?></h5>
                          <div>
                            <iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php echo e($details->latitude); ?>,%20<?php echo e($details->longitude); ?>+(My%20Business%20Name)&amp;t=&amp;z=15&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
                          </div>
                        <?php endif; ?>
                      </div>

                      <div role="tabpanel" class="tab-pane fade" id="reviews">
                        <div class="comment-area">
                          <h5 class="tab-title"><?php echo e(__('Reviews')); ?></h5>

                          <?php if(count($reviews) == 0): ?>
                            <div class="bg-light py-5">
                              <h6 class="text-center"><?php echo e(__('This Room Has No Review Yet.')); ?></h6>
                            </div>
                          <?php else: ?>
                            <ul class="comment-list">
                              <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                  <?php
                                    $user = $review->roomReviewedByUser()->first();
                                  ?>

                                  <div class="comment-user">
                                    <img class="lazy" data-src="<?php echo e(!empty($user->image) ? asset('assets/img/users/' . $user->image) : asset('assets/img/user-profile.jpg')); ?>" alt="user image">
                                  </div>

                                  <div class="comment-desc">
                                    <h6><?php echo e($user->first_name . ' ' . $user->last_name); ?> <span class="comment-date"> <?php echo e(date_format($review->created_at, 'd M Y')); ?></span></h6>

                                    <p><?php echo e($review->comment); ?></p>

                                    <div class="user-rating">
                                      <?php for($i = 1; $i <= $review->rating; $i++): ?>
                                        <i class="fa fa-star"></i>
                                      <?php endfor; ?>
                                    </div>
                                  </div>
                                </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                          <?php endif; ?>
                        </div>

                        <?php if(auth()->guard('web')->guest()): ?>
                          <h5><?php echo e(__('Please')); ?> <a href="<?php echo e(route('user.login', ['redirectPath' => 'room_details'])); ?>"><?php echo e(__('Login')); ?></a> <?php echo e(__('To Give Your Review.')); ?></h5>
                        <?php endif; ?>

                        <?php if(auth()->guard('web')->check()): ?>
                          <div class="review-form">
                            <h5 class="tab-title"><?php echo e(__('Give Your Review')); ?></h5>
                            <form action="<?php echo e(route('room.store_review', ['id' => $details->room_id])); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <div class="mb-25">
                                <div class="review-content">
                                  <ul class="review-value review-1">
                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="1">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>
                                  </ul>

                                  <ul class="review-value review-2">
                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="2">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="2">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>
                                  </ul>

                                  <ul class="review-value review-3">
                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="3">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="3">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="3">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>
                                  </ul>

                                  <ul class="review-value review-4">
                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="4">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="4">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="4">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="4">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>
                                  </ul>

                                  <ul class="review-value review-5">
                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="5">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="5">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="5">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="5">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>

                                    <li>
                                      <a class="cursor-pointer" data-ratingVal="5">
                                        <i class="far fa-star"></i>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                              </div>

                              <input type="hidden" id="ratingId" name="rating">

                              <div class="input-wrap text-area">
                                <textarea placeholder="<?php echo e(__('Review')); ?>" name="comment"><?php echo e(old('comment')); ?></textarea>
                                <i class="far fa-pencil"></i>
                              </div>

                              <div class="input-wrap">
                                <button type="submit" class="btn btn-block"><?php echo e(__('Submit')); ?></button>
                              </div>
                            </form>
                          </div>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Room Details Section End -->

          <!-- Sidebar Area Start -->
          <div class="col-lg-4">
            <div class="sidebar-wrap">
              <div class="widget booking-widget">
                <h4 class="widget-title">
                  <?php echo e($position == 'left' ? $symbol : ''); ?><?php echo e($details->room->rent); ?><?php echo e($position == 'right' ? $symbol : ''); ?> / <span><?php echo e(__('Night')); ?></span>
                </h4>

                <?php if((Auth::guard('web')->check() == false) && ($status->room_guest_checkout_status == 1)): ?>
                  <div class="alert alert-warning">
                    <?php echo e(__('You are now booking as a guest. if you want to log in before booking, then please')); ?> <a href="<?php echo e(route('user.login', ['redirectPath' => 'room_details'])); ?>"><?php echo e(__('Click Here')); ?></a>
                  </div>
                <?php endif; ?>

                <form action="<?php echo e(route('room_booking')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="room_id" value="<?php echo e($details->room_id); ?>">

                  <div class="mb-2">
                    <div class="input-wrap">
                      <input type="text" placeholder="<?php echo e(__('Check In / Out Date')); ?>" id="date-range" name="dates" value="<?php echo e(old('dates')); ?>" readonly>
                      <i class="far fa-calendar-alt"></i>
                    </div>
                    <?php $__errorArgs = ['dates'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="ml-2 mt-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-2">
                    <div class="input-wrap">
                      <input type="text" placeholder="<?php echo e(__('Number of Nights')); ?>" id="night" name="nights" value="<?php echo e(old('nights')); ?>" readonly>
                      <i class="fas fa-moon"></i>
                    </div>
                    <small class="text-primary mt-2 <?php echo e($currentLanguageInfo->direction == 0 ? 'ml-2' : 'mr-2'); ?> mb-0">
                      <?php echo e(__('Number of nights will be calculated based on checkin & checkout date')); ?>

                    </small>
                    <?php $__errorArgs = ['nights'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="ml-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-2">
                    <div class="input-wrap">
                      <input type="text" placeholder="<?php echo e(__('Number of Guests')); ?>" name="guests" value="<?php echo e(old('guests')); ?>">
                      <i class="far fa-users"></i>
                    </div>
                    <?php $__errorArgs = ['guests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="ml-2 mt-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-2">
                    <div class="input-wrap">
                      <?php if(auth()->guard('web')->guest()): ?>
                        <input type="text" placeholder="<?php echo e(__('Full Name')); ?>" name="customer_name" value="<?php echo e(old('customer_name')); ?>">
                      <?php endif; ?>

                      <?php if(auth()->guard('web')->check()): ?>
                        <?php
                          if (!empty(Auth::guard('web')->user()->first_name) || !empty(Auth::guard('web')->user()->last_name)) {
                            $name = Auth::guard('web')->user()->first_name . ' ' . Auth::guard('web')->user()->last_name;
                          } else {
                            $name = '';
                          }
                        ?>

                        <input type="text" placeholder="<?php echo e(__('Full Name')); ?>" name="customer_name" value="<?php echo e($name); ?>">
                      <?php endif; ?>
                      <i class="far fa-user"></i>
                    </div>
                    <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="ml-2 mt-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-2">
                    <div class="input-wrap">
                      <?php if(auth()->guard('web')->guest()): ?>
                        <input type="text" placeholder="<?php echo e(__('Phone')); ?>" name="customer_phone" value="<?php echo e(old('customer_phone')); ?>">
                      <?php endif; ?>

                      <?php if(auth()->guard('web')->check()): ?>
                        <input type="text" placeholder="<?php echo e(__('Phone')); ?>" name="customer_phone" value="<?php echo e(Auth::guard('web')->user()->contact_number); ?>">
                      <?php endif; ?>
                      <i class="far fa-phone"></i>
                    </div>
                    <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="ml-2 mt-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-2">
                    <div class="input-wrap">
                      <?php if(auth()->guard('web')->guest()): ?>
                        <input type="email" placeholder="<?php echo e(__('Email')); ?>" name="customer_email" value="<?php echo e(old('customer_email')); ?>">
                      <?php endif; ?>

                      <?php if(auth()->guard('web')->check()): ?>
                        <input type="email" placeholder="<?php echo e(__('Email')); ?>" name="customer_email" value="<?php echo e(Auth::guard('web')->user()->email); ?>">
                      <?php endif; ?>
                      <i class="far fa-envelope"></i>
                    </div>
                    <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="ml-2 mt-2 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-2">
                    <div class="input-wrap">
                      <select class="nice-select" name="paymentType" id="payment-gateways">
                        <option selected value="none">
                          <?php echo e(__('Select Payment Gateway')); ?>

                        </option>
                        <?php $__currentLoopData = $onlineGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onlineGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($onlineGateway->keyword); ?>">
                            <?php echo e($onlineGateway->name); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(!empty($offlineGateways)): ?>
                          <?php $__currentLoopData = $offlineGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offlineGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($offlineGateway['id']); ?>">
                              <?php echo e($offlineGateway['name']); ?>

                            </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </select>
                    </div>
                  </div>

                  <div class="row d-none" id="tab-stripe">
                    <div class="col-12">
                      <div class="field-input">
                        <input type="text" class="card-elements mb-2" name="card_number" placeholder="<?php echo e(__('Card Number')); ?>" autocomplete="off" value="<?php echo e(old('card_number')); ?>">
                      </div>
                      <?php $__errorArgs = ['card_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mb-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12">
                      <div class="field-input">
                        <input type="text" class="card-elements mb-2" placeholder="<?php echo e(__('CVC Number')); ?>" name="cvc_number" value="<?php echo e(old('cvc_number')); ?>">
                      </div>
                      <?php $__errorArgs = ['cvc_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mb-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12">
                      <div class="field-input">
                        <input type="text" class="card-elements mb-2" placeholder="<?php echo e(__('Expiry Month')); ?>" name="expiry_month" value="<?php echo e(old('expiry_month')); ?>">
                      </div>
                      <?php $__errorArgs = ['expiry_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mb-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 mb-4">
                      <div class="field-input">
                        <input type="text" class="card-elements" placeholder="<?php echo e(__('Expiry Year')); ?>" name="expiry_year" value="<?php echo e(old('expiry_year')); ?>">
                      </div>
                      <?php $__errorArgs = ['expiry_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="ml-2 mt-2 text-danger"><?php echo e(convertUtf8($message)); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="d-none my-3 px-2" id="gateway-description"></div>

                  <div class="d-none mb-3 px-2" id="gateway-instruction"></div>

                  <div class="input-wrap d-none mb-4 pl-2" id="gateway-attachment">
                    <input type="file" name="attachment">
                  </div>

                  <div class="mb-2">
                    <div class="input-wrap d-flex">
                      <input type="text" id="coupon-code" placeholder="<?php echo e(__('Enter Your Coupon')); ?>">
                      <button type="button" class="btn filled-btn" onclick="applyCoupon(event)" style="padding: 0px 15px;">
                        <?php echo e(__('Apply')); ?>

                      </button>
                    </div>
                  </div>

                  <div class="price-option-table mt-4">
                    <ul>
                      <li class="single-price-option">
                        <span class="title"><?php echo e(__('Subtotal')); ?> <span class="amount"><?php echo e($position == 'left' ? $symbol : ''); ?><span id="subtotal-amount">0.00</span><?php echo e($position == 'right' ? $symbol : ''); ?></span></span>
                      </li>

                      <li class="single-price-option">
                        <span class="title"><?php echo e(__('Discount')); ?> <span class="text-success">(<i class="fas fa-minus"></i>)</span> <span class="amount"><?php echo e($position == 'left' ? $symbol : ''); ?><span id="discount-amount">0.00</span><?php echo e($position == 'right' ? $symbol : ''); ?></span></span>
                      </li>

                      <li class="single-price-option">
                        <span class="title"><?php echo e(__('Total')); ?> <span class="amount"><?php echo e($position == 'left' ? $symbol : ''); ?><span id="total-amount">0.00</span><?php echo e($position == 'right' ? $symbol : ''); ?></span></span>
                      </li>
                    </ul>
                  </div>

                  <div class="mt-4">
                    <div class="input-wrap">
                      <button type="submit" class="btn filled-btn btn-block">
                        <?php echo e(__('book now')); ?> <i class="far fa-long-arrow-right"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <!-- Sidebar Area End -->
        </div>
      </div>
    </section>

    <!-- Latest Room Start -->
    <section class="latest-room-d section-bg section-padding">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <h1><?php echo e(__('Related Rooms')); ?></h1>
        </div>

        <div class="row">
          <?php $__currentLoopData = $latestRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
              <!-- Single Room -->
              <div class="single-room">
                <a class="room-thumb d-block" href="<?php echo e(route('room_details', [$latestRoom->room->id, $latestRoom->slug])); ?>">
                  <img class="lazy" data-src="<?php echo e(asset('assets/img/rooms/' . $latestRoom->room->featured_img)); ?>" alt="room">
                  <div class="room-price">
                    <p><?php echo e($position == 'left' ? $symbol : ''); ?><?php echo e($latestRoom->room->rent); ?><?php echo e($position == 'right' ? $symbol : ''); ?> / <?php echo e(__('Night')); ?></p>
                  </div>
                </a>
                <div class="room-desc">
                  <?php if($websiteInfo->room_category_status == 1): ?>
                    <div class="room-cat">
                      <a class="p-0 d-block" href="<?php echo e(route('rooms', ['category' => $latestRoom->roomCategory->id])); ?>"><?php echo e($latestRoom->roomCategory->name); ?></a>
                    </div>
                  <?php endif; ?>
                  <h4>
                    <a href="<?php echo e(route('room_details', ['id' => $latestRoom->room_id, 'slug' => $latestRoom->slug])); ?>"><?php echo e(convertUtf8($latestRoom->title)); ?></a>
                  </h4>
                  <p><?php echo e($latestRoom->summary); ?></p>
                  <ul class="room-info">
                    <li><i class="far fa-bed"></i><?php echo e($latestRoom->room->bed); ?> <?php echo e($latestRoom->room->bed == 1 ? __('Bed') : __('Beds')); ?></li>
                    <li><i class="far fa-bath"></i><?php echo e($latestRoom->room->bath); ?> <?php echo e($latestRoom->room->bath == 1 ? __('Bath') : __('Baths')); ?></li>
                    <?php if(!empty($latestRoom->room->max_guests)): ?>
                      <li><i class="far fa-users"></i><?php echo e($latestRoom->room->max_guests); ?> <?php echo e($latestRoom->room->max_guests == 1 ? __('Guest') : __('Guests')); ?></li>
                    <?php endif; ?>
                  </ul>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <!-- Latest Room End -->
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script>
    'use strict';

    // assign php value to js variable
    var bookingDates = <?php echo json_encode($bookingDates); ?>;
    var offlineGateways = <?php echo json_encode($offlineGateways); ?>;
    var roomRentPerNight = '<?php echo e($details->rent); ?>';
  </script>

  <script src="<?php echo e(asset('assets/js/room-details.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/rooms/room_details.blade.php ENDPATH**/ ?>