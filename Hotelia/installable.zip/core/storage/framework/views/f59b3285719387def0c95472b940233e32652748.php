<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Booking Details')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Packages Management')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Package Bookings')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Booking Details')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="card-title d-inline-block"><?php echo e(__('Package Booking Details')); ?></div>
          <a
            class="btn btn-info btn-sm float-right d-inline-block"
            href="<?php echo e(url()->previous()); ?>"
          >
            <span class="btn-label">
              <i class="fas fa-backward" style="font-size: 12px;"></i>
            </span>
            <?php echo e(__('Back')); ?>

          </a>
        </div>

        <?php
          $position = $details->currency_text_position;
          $currency = $details->currency_text;
        ?>

        <div class="card-body">
          <div class="container">
            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('booking number:')); ?></strong>
              </div>
              <div class="col-lg-8"><?php echo e('#' . $details->booking_number); ?></div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('booking date:')); ?></strong>
              </div>
              <div class="col-lg-8">
                <?php echo e(date_format($details->created_at, 'F d, Y')); ?>

              </div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('customer name:')); ?></strong>
              </div>
              <div class="col-lg-8"><?php echo e(convertUtf8($details->customer_name)); ?></div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('customer email:')); ?></strong>
              </div>
              <div class="col-lg-8"><?php echo e($details->customer_email); ?></div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('customer phone:')); ?></strong>
              </div>
              <div class="col-lg-8"><?php echo e($details->customer_phone); ?></div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('package name:')); ?></strong>
              </div>
              <div class="col-lg-8"><?php echo e($packageTitle); ?></div>
            </div>
            <hr>

            <?php if($packageCategoryName != null): ?>
              <div class="row">
                <div class="col-lg-4">
                  <strong style="text-transform: capitalize;"><?php echo e(__('package type:')); ?></strong>
                </div>
                <div class="col-lg-8"><?php echo e($packageCategoryName); ?></div>
              </div>
              <hr>
            <?php endif; ?>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('number of visitors:')); ?></strong>
              </div>
              <div class="col-lg-8"><?php echo e($details->visitors); ?></div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('subtotal:')); ?></strong>
              </div>
              <div class="col-lg-8">
                <?php echo e($position == 'left' ? $currency . ' ' : ''); ?><?php echo e($details->subtotal); ?><?php echo e($position == 'right' ? ' ' . $currency : ''); ?>

              </div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('discount:')); ?></strong>
              </div>
              <div class="col-lg-8">
                <?php echo e($position == 'left' ? $currency . ' ' : ''); ?><?php echo e($details->discount); ?><?php echo e($position == 'right' ? ' ' . $currency : ''); ?>

              </div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('total cost:')); ?></strong>
              </div>
              <div class="col-lg-8">
                <?php echo e($position == 'left' ? $currency . ' ' : ''); ?><?php echo e($details->grand_total); ?><?php echo e($position == 'right' ? ' ' . $currency : ''); ?>

              </div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('payment method:')); ?></strong>
              </div>
              <div class="col-lg-8"><?php echo e($details->payment_method); ?></div>
            </div>
            <hr>

            <div class="row">
              <div class="col-lg-4">
                <strong style="text-transform: capitalize;"><?php echo e(__('payment status:')); ?></strong>
              </div>
              <div class="col-lg-8">
                <?php echo e($details->payment_status == 1 ? 'Paid' : 'Unpaid'); ?>

              </div>
            </div>
          </div>
        </div>

        <div class="card-footer"></div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/packages/booking_details.blade.php ENDPATH**/ ?>