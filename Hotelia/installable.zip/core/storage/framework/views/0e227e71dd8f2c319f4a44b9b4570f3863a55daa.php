<footer>
  <div class="container">
    <?php if($sections->top_footer_section == 1): ?>
    <div class="footer-top">
      <div class="row">
        <div class="col-lg-4 col-md-6">
          <div class="widget footer-widget">
            <?php if(!is_null($websiteInfo->footer_logo)): ?>
              <div class="footer-logo">
                <img class="lazy" data-src="<?php echo e(asset('assets/img/' . $websiteInfo->footer_logo)); ?>" alt="footer logo">
              </div>
            <?php endif; ?>

            <?php if(!is_null($footerInfo)): ?>
              <p><?php echo e($footerInfo->about_company); ?></p>
            <?php endif; ?>

            <?php if(count($socialLinkInfos) > 0): ?>
              <ul class="social-icons">
                <?php $__currentLoopData = $socialLinkInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialLinkInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <a href="<?php echo e($socialLinkInfo->url); ?>"><i class="<?php echo e($socialLinkInfo->icon); ?>"></i></a>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>

        <div class="col-lg-4 col-md-6">
          <div class="widget footer-widget">
            <h4 class="widget-title"><?php echo e(__('Quick Links')); ?></h4>
            <?php if(count($quickLinkInfos) == 0): ?>
              <h5 class="text-white"><?php echo e(__('No Quick Link Found!')); ?></h5>
            <?php else: ?>
              <ul class="nav-widget clearfix">
                <?php $__currentLoopData = $quickLinkInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quickLinkInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo e($quickLinkInfo->url); ?>"><?php echo e($quickLinkInfo->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="widget footer-widget">
            <h4 class="widget-title"><?php echo e(__('Recent Blogs')); ?></h4>
            <?php if(count($footerBlogInfos) == 0): ?>
              <h5 class="text-white"><?php echo e(__('No Recent Blog Found!')); ?></h5>
            <?php else: ?>
              <ul class="recent-post">
                <?php $__currentLoopData = $footerBlogInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerBlogInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <h6>
                      <a href="<?php echo e(route('blog_details', ['id' => $footerBlogInfo->blog_id, 'slug' => $footerBlogInfo->slug])); ?>">
                        <?php echo e(strlen($footerBlogInfo->title) > 40 ? mb_substr($footerBlogInfo->title, 0, 40, 'UTF-8') . '...' : $footerBlogInfo->title); ?>

                      </a>
                    </h6>
                    <span class="recent-post-date"><?php echo e(date_format($footerBlogInfo->blog->created_at, 'F d, Y')); ?></span>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <?php if($sections->copyright_section == 1): ?>
    <div class="footer-bottom">
      <div class="row text-center">

        <div class="col-md-12">
          <?php if(!is_null($footerInfo)): ?>
            <p class="copy-right text-center">
              <?php echo replaceBaseUrl($footerInfo->copyright_text, 'summernote'); ?>

            </p>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</footer>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/partials/footer.blade.php ENDPATH**/ ?>