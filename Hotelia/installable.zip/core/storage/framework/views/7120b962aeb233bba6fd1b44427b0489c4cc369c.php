<div class="col-lg-3">
  <div class="user-sidebar">
    <ul class="links">
      <li class="<?php echo e(request()->routeIs('user.dashboard') ? 'active-menu' : ''); ?>">
        <a href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
      </li>

      <li class="<?php echo e(request()->routeIs('user.room_bookings') || request()->routeIs('user.room_booking_details') ? 'active-menu' : ''); ?>">
        <a href="<?php echo e(route('user.room_bookings')); ?>"><?php echo e(__('Room Bookings')); ?></a>
      </li>

      <li class="<?php echo e(request()->routeIs('user.package_bookings') || request()->routeIs('user.package_booking_details') ? 'active-menu' : ''); ?>">
        <a href="<?php echo e(route('user.package_bookings')); ?>"><?php echo e(__('Package Bookings')); ?></a>
      </li>

      <li class="<?php echo e(request()->routeIs('user.edit_profile') ? 'active-menu' : ''); ?>">
        <a href="<?php echo e(route('user.edit_profile')); ?>"><?php echo e(__('Edit Profile')); ?></a>
      </li>

      <li class="<?php echo e(request()->routeIs('user.change_password') ? 'active-menu' : ''); ?>">
        <a href="<?php echo e(route('user.change_password')); ?>"><?php echo e(__('Change Password')); ?></a>
      </li>

      <li><a href="<?php echo e(route('user.logout')); ?>"><?php echo e(__('Logout')); ?></a></li>
    </ul>
  </div>
</div>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/user/side_navbar.blade.php ENDPATH**/ ?>