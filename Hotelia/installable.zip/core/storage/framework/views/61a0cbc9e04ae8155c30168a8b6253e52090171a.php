<?php $__env->startSection('pageHeading'); ?>
  <?php if(!is_null($pageHeading)): ?>
    <?php echo e($pageHeading->rooms_title); ?>

  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php
    $metaKeywords = !empty($seo->meta_keyword_rooms) ? $seo->meta_keyword_rooms : '';
    $metaDesc = !empty($seo->meta_description_rooms) ? $seo->meta_description_rooms : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeywords"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <?php if(!is_null($pageHeading)): ?>
            <h1><?php echo e(convertUtf8($pageHeading->rooms_title)); ?></h1>
          <?php endif; ?>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>

            <?php if(!is_null($pageHeading)): ?>
              <li><?php echo e(convertUtf8($pageHeading->rooms_title)); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- All Rooms Section Start -->
    <section class="rooms-warp list-view section-bg section-padding">
      <div class="container">

        <div class="row">
            <?php if($websiteInfo->room_category_status == 1): ?>
            <div class="col-12">
              <div class="filter-view">
                <ul>
                    <li <?php if(empty(request()->input('category'))): ?> class="active-f-view" <?php endif; ?>><a href="<?php echo e(route('rooms')); ?>"><?php echo e(__('All')); ?></a></li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li <?php if(request()->input('category') == $cat->id): ?> class="active-f-view" <?php endif; ?>><a href="<?php echo e(route('rooms') . '?category=' . $cat->id); ?>"><?php echo e($cat->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
            <?php endif; ?>

          <?php if ($__env->exists('frontend.rooms.grid_view')) echo $__env->make('frontend.rooms.grid_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <?php if ($__env->exists('frontend.rooms.room_sidebar')) echo $__env->make('frontend.rooms.room_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

      </div>
    </section>
    <!-- All Rooms Section Start -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/rooms/rooms.blade.php ENDPATH**/ ?>