
<div class="modal fade" id="roomModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('All Rooms')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <form id="roomSelectForm" action="<?php echo e(route('admin.room_bookings.get_booked_dates')); ?>" method="GET">
          <div class="row">
            <div class="col-lg-12">
              <div class="form-group">
                <select name="room_id" class="form-control" id="selected-room">
                  <option selected disabled><?php echo e(__('Select a Room')); ?></option>
                  <?php $__currentLoopData = $roomInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($roomInfo->room_id); ?>"><?php echo e($roomInfo->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <p id="err_room_id" class="mt-1 mb-0 ml-1 text-danger em"></p>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" id="roomBookingNextBtn" class="btn btn-sm btn-primary">
          <?php echo e(__('Next')); ?>

        </button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/rooms/all_rooms.blade.php ENDPATH**/ ?>