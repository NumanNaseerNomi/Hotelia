<footer class="footer">
  <div class="container-fluid">
    <div class="d-block mx-auto">
      <?php echo !is_null($footerTextInfo) ? replaceBaseUrl($footerTextInfo->copyright_text, 'summernote') : ''; ?>

    </div>
  </div>
</footer>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/partials/footer.blade.php ENDPATH**/ ?>