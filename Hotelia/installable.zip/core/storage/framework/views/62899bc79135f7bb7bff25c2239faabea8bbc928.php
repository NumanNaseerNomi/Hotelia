    <!-- Hero Section Start -->
    <section class="hero-section" id="heroSlideActive">
        <?php if(count($sliders) != 0): ?>
          <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
              class="single-hero-slide bg-img-center d-flex align-items-center text-center lazy"
              data-bg="<?php echo e(asset('assets/img/hero_slider/' . $slider->img)); ?>"
            >
              <div class="container">
                <div class="slider-text">
                  <span class="small-text" data-animation="fadeInDown" data-delay=".3s"><?php echo e(convertUtf8($slider->title)); ?></span>
                  <h1 data-animation="fadeInLeft" data-delay=".6s"><?php echo e(convertUtf8($slider->subtitle)); ?></h1>
                  <a class="btn filled-btn" href="<?php echo e($slider->btn_url); ?>" data-animation="fadeInUp" data-delay=".9s">
                    <?php echo e(convertUtf8($slider->btn_name)); ?> <i class="far fa-long-arrow-right"></i>
                  </a>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="bg-light pt-70 pb-130 text-center">
                <h3><?php echo e(__('No Slider Found!')); ?></h4>
            </div>
        <?php endif; ?>
      </section>
      <!-- Hero Section End -->
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/partials/hero/theme1/slider.blade.php ENDPATH**/ ?>