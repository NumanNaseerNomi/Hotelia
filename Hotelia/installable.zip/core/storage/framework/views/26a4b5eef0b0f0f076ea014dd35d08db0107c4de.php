<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Home')); ?>

<?php $__env->stopSection(); ?>

<?php
    $metaKeywords = !empty($seo->meta_keyword_home) ? $seo->meta_keyword_home : '';
    $metaDescription = !empty($seo->meta_description_home) ? $seo->meta_description_home : '';
?>
<?php $__env->startSection('meta-keywords', "<?php echo e($metaKeywords); ?>"); ?>
<?php $__env->startSection('meta-description', "$metaDescription"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <?php
        if(!empty($hero)) {
            $img = $hero->img;
            $title = $hero->title;
            $subtitle = $hero->subtitle;
            $btnUrl = $hero->btn_url;
            $btnName = $hero->btn_name;
        } else {
            $img = '';
            $title = '';
            $subtitle = '';
            $btnUrl = '';
            $btnName = '';
        }
    ?>
    <?php if($websiteInfo->home_version == 'static'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme1.static')) echo $__env->make('frontend.partials.hero.theme1.static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'slider'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme1.slider')) echo $__env->make('frontend.partials.hero.theme1.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'video'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme1.video')) echo $__env->make('frontend.partials.hero.theme1.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'particles'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme1.particles')) echo $__env->make('frontend.partials.hero.theme1.particles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'water'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme1.water')) echo $__env->make('frontend.partials.hero.theme1.water', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($websiteInfo->home_version == 'parallax'): ?>
        <?php if ($__env->exists('frontend.partials.hero.theme1.parallax')) echo $__env->make('frontend.partials.hero.theme1.parallax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($sections->search_section == 1): ?>
    <!-- Booking Search Form Start -->
    <section class="booking-section">
      <div class="container">
        <div class="booking-form-wrap bg-img-center section-bg">
          <form action="<?php echo e(route('rooms')); ?>" method="GET">
            <div class="row no-gutters">
              <div class="col-lg-3 col-md-6">
                <div class="input-wrap">
                  <input type="text" placeholder="<?php echo e(__('Check In / Out Date')); ?>" id="date-range" name="dates" readonly>
                  <i class="far fa-calendar-alt"></i>
                </div>
              </div>

              <div class="col-lg-2 col-md-6">
                <div class="input-wrap">
                  <select name="beds" class="nice-select">
                    <option selected disabled><?php echo e(__('Beds')); ?></option>

                    <?php for($i = 1; $i <= $numOfBed; $i++): ?>
                      <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
              </div>

              <div class="col-lg-2 col-md-6">
                <div class="input-wrap">
                  <select name="baths" class="nice-select">
                    <option selected disabled><?php echo e(__('Baths')); ?></option>

                    <?php for($i = 1; $i <= $numOfBath; $i++): ?>
                      <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
              </div>

              <div class="col-lg-2 col-md-6">
                <div class="input-wrap">
                  <select name="guests" class="nice-select">
                    <option selected disabled><?php echo e(__('Guests')); ?></option>

                    <?php for($i = 1; $i <= $numOfGuest; $i++): ?>
                      <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
              </div>

              <div class="col-lg-3 col-md-6">
                <div class="input-wrap">
                  <button type="submit" class="btn filled-btn btn-block rounded-0">
                    <?php echo e(__('search')); ?> <i class="far fa-long-arrow-right"></i>
                  </button>
                </div>
              </div>
            </div>
          </form>

          <div class="booking-shape-1">
            <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/01.png')); ?>" alt="shape">
          </div>
          <div class="booking-shape-2">
            <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/02.png')); ?>" alt="shape">
          </div>
          <div class="booking-shape-3">
            <img class="lazy" data-src="<?php echo e(asset('assets/img/shape/03.png')); ?>" alt="shape">
          </div>
        </div>
      </div>
    </section>
    <!-- Booking Search Form End -->
    <?php endif; ?>

    <?php if($sections->intro_section == 1): ?>
    <!-- Welcome Section Start -->
    <section class="welcome-section section-padding">
      <div class="container">
        <div class="row align-items-center no-gutters">
          <!-- Title Gallery Start -->
          <div class="col-lg-6">
            <div class="title-gallery">
              <?php if(!is_null($intro)): ?>
                <img class="lazy" data-src="<?php echo e(asset('assets/img/intro_section/' . $intro->intro_img)); ?>" alt="image">
              <?php endif; ?>
            </div>
          </div>
          <!-- Title Gallery End -->

          <div class="col-lg-5 offset-lg-1">
            <!-- Section Title -->
            <div class="section-title">
              <?php if(!is_null($intro)): ?>
                <span class="title-top with-border"><?php echo e($intro->intro_primary_title); ?></span>
                <h1><?php echo e($intro->intro_secondary_title); ?></h1>
                <p><?php echo e($intro->intro_text); ?></p>
              <?php endif; ?>
            </div>

            <?php if($sections->statistics_section == 1): ?>
            <!-- Counter Start -->
            <div class="counter">
              <div class="row">
                <?php if(count($counterInfos) > 0): ?>
                  <?php $__currentLoopData = $counterInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counterInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4">
                      <div class="counter-box">
                        <i class="<?php echo e($counterInfo->icon); ?>"></i>
                        <span class="counter-number"><?php echo e($counterInfo->amount); ?></span>
                        <p><?php echo e($counterInfo->title); ?></p>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            </div>
            <!-- Counter End -->
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>
    <!-- Welcome Section End -->
    <?php endif; ?>


    <?php if($sections->featured_rooms_section == 1): ?>
    <!-- Latest Room Section Start -->
    <section class="latest-room section-bg section-padding">
      <div class="container-fluid">
        <div class="row align-items-center no-gutters">
          <div class="col-lg-3">
            <!-- Section Title -->
            <div class="section-title">
              <?php if(!is_null($secHeading)): ?>
                <span class="title-top with-border"><?php echo e(convertUtf8($secHeading->room_section_title)); ?></span>
                <h1><?php echo e(convertUtf8($secHeading->room_section_subtitle)); ?></h1>
                <p><?php echo e($secHeading->room_section_text); ?></p>
              <?php endif; ?>
              <!-- Page Info -->
              <div class="page-Info"></div>
              <!-- Room Arrow -->
              <div class="room-arrows"></div>
            </div>
          </div>

          <div class="col-lg-8 offset-lg-1">
            <?php if(count($roomInfos) == 0 || $roomFlag == 0): ?>
              <h3 class="text-center text-white"><?php echo e(__('No Featured Room Found!')); ?></h3>
            <?php else: ?>
              <div class="latest-room-slider" id="roomSliderActive">
                <?php $__currentLoopData = $roomInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(!is_null($roomInfo->room)): ?>
                      <div class="single-room">
                        <a class="room-thumb d-block" href="<?php echo e(route('room_details', [$roomInfo->room_id, $roomInfo->slug])); ?>">
                          <img class="lazy" data-src="<?php echo e(asset('assets/img/rooms/' . $roomInfo->room->featured_img)); ?>" alt="">
                          <div class="room-price">
                            <p><?php echo e($currencyInfo->base_currency_symbol_position == 'left' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e($roomInfo->room->rent); ?> <?php echo e($currencyInfo->base_currency_symbol_position == 'right' ? $currencyInfo->base_currency_symbol : ''); ?> / <?php echo e(__('Night')); ?></p>
                          </div>
                        </a>
                        <div class="room-desc">
                            <?php if($websiteInfo->room_category_status == 1): ?>
                            <div class="room-cat">
                              <a class="d-block p-0" href="<?php echo e(route('rooms', ['category' => $roomInfo->roomCategory->id])); ?>"><?php echo e($roomInfo->roomCategory->name); ?></a>
                            </div>
                            <?php endif; ?>
                          <h4>
                            <a href="<?php echo e(route('room_details', ['id' => $roomInfo->room_id, 'slug' => $roomInfo->slug])); ?>"><?php echo e(convertUtf8($roomInfo->title)); ?></a>
                          </h4>
                          <p><?php echo e($roomInfo->summary); ?></p>
                          <ul class="room-info">
                            <li><i class="far fa-bed"></i><?php echo e($roomInfo->room->bed); ?> <?php echo e($roomInfo->room->bed == 1 ? __('Bed') : __('Beds')); ?></li>
                            <li><i class="far fa-bath"></i><?php echo e($roomInfo->room->bath); ?> <?php echo e($roomInfo->room->bath == 1 ? __('Bath') : __('Baths')); ?></li>
                            <?php if(!empty($roomInfo->room->max_guests)): ?>
                            <li><i class="far fa-users"></i><?php echo e($roomInfo->room->max_guests); ?> <?php echo e($roomInfo->room->max_guests == 1 ? __('Guest') : __('Guests')); ?></li>
                            <?php endif; ?>
                          </ul>
                        </div>
                      </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>
    <!-- Latest Room Section End -->
    <?php endif; ?>

    <?php if($sections->featured_services_section == 1): ?>
    <!-- Service Section Start -->
    <section class="service-section section-padding">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <?php if(!empty($secHeading)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <span class="title-top"><?php echo e(convertUtf8($secHeading->service_section_title)); ?></span>
                    <h1><?php echo e(convertUtf8($secHeading->service_section_subtitle)); ?></h1>
                </div>
            </div>
          <?php endif; ?>
        </div>

        <!-- Service Boxes -->
        <?php if(count($serviceInfos) == 0 || $serviceFlag == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Featured Service Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $serviceInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(!is_null($serviceInfo->service)): ?>
                <div class="col-lg-4 col-md-6">
                  <div
                    class="single-service-box text-center wow fadeIn animated"
                    data-wow-duration="1500ms"
                    data-wow-delay="<?php echo e($loop->iteration * 200); ?>ms"
                  >
                    <span class="service-counter"><?php echo e($loop->iteration); ?></span>
                    <div class="service-icon">
                      <i class="<?php echo e($serviceInfo->service->service_icon); ?>"></i>
                    </div>
                    <h4><?php echo e(convertUtf8($serviceInfo->title)); ?></h4>
                    <p><?php echo e(strlen($serviceInfo->summary) > 35 ? substr($serviceInfo->summary, 0, 35) . '...' : $serviceInfo->summary); ?></p>
                    <?php if($serviceInfo->service->details_page_status == 1): ?>
                      <a href="<?php echo e(route('service_details', ['id' => $serviceInfo->service_id, 'slug' => $serviceInfo->slug])); ?>" class="read-more">
                        <?php echo e(__('read more')); ?> <i class="far fa-long-arrow-right"></i>
                      </a>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Service Section End -->
    <?php endif; ?>


    <?php if($sections->video_section == 1): ?>
    <!-- Call To Action Start -->
    <section class="cta-section bg-img-center lazy <?php echo e($websiteInfo->home_version == 'parallax' ? 'parallax' : ''); ?>" data-bg="<?php echo e(asset('assets/img/booking-img.jpg')); ?>">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-10">
            <div class="cta-left-content">
              <?php if(!is_null($secHeading)): ?>
                <span><?php echo e(convertUtf8($secHeading->booking_section_title)); ?></span>
                <h1><?php echo e(convertUtf8($secHeading->booking_section_subtitle)); ?></h1>
                <a href="<?php echo e($secHeading->booking_section_button_url); ?>" class="btn filled-btn">
                  <?php echo e($secHeading->booking_section_button); ?> <i class="far fa-long-arrow-right"></i>
                </a>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-md-2">
            <?php if(!is_null($secHeading)): ?>
              <div class="video-icon text-right">
                <a href="<?php echo e($secHeading->booking_section_video_url); ?>" class="video-popup"> <i class="fas fa-play"></i></a>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>
    <!-- Call To Action End -->
    <?php endif; ?>

    <?php if($sections->featured_package_section == 1): ?>
    <!-- Package Section Start -->
    <section class="ma-package-section section-padding featured-packages">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
            <?php if(!empty($secHeading)): ?>
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <span class="title-top"><?php echo e(convertUtf8($secHeading->package_section_title)); ?></span>
                        <h1><?php echo e(convertUtf8($secHeading->package_section_subtitle)); ?></h1>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Package Boxes -->
        <?php if(count($packageInfos) == 0 || $packageFlag == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Featured Package Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $packageInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(!is_null($packageInfo->package)): ?>
                <div class="col-lg-6">
                  <div class="packages-post-item">
                    <a class="post-thumbnail d-block" href="<?php echo e(route('package_details', ['id' => $packageInfo->package_id, 'slug' => $packageInfo->slug])); ?>">
                      <img class="lazy" data-src="<?php echo e(asset('assets/img/packages/' . $packageInfo->package->featured_img)); ?>" alt="package img">
                    </a>

                    <div class="entry-content">
                      <h3 class="title">
                        <a href="<?php echo e(route('package_details', ['id' => $packageInfo->package_id, 'slug' => $packageInfo->slug])); ?>"><?php echo e(strlen($packageInfo->title) > 50 ? mb_substr($packageInfo->title, 0, 50, 'utf-8') . '...' : $packageInfo->title); ?></a>
                      </h3>
                      <div class="post-meta">
                        <ul>

                          <?php if($packageInfo->package->pricing_type != 'negotiable'): ?>
                            <li><span><i class="fas fa-comment-dollar"></i><strong><?php echo e(__('Package Price') . ':'); ?></strong> <?php echo e($currencyInfo->base_currency_symbol_position == 'left' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e($packageInfo->package->package_price); ?> <?php echo e($currencyInfo->base_currency_symbol_position == 'right' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e('(' . __(strtoupper($packageInfo->package->pricing_type)) . ')'); ?></span></li>
                          <?php else: ?>
                            <li><span><i class="fas fa-comment-dollar"></i><strong><?php echo e(__('Package Price') . ':'); ?></strong> <?php echo e(__('NEGOTIABLE')); ?></span></li>
                          <?php endif; ?>

                          <li><span><i class="fas fa-users"></i><strong><?php echo e(__('Number of Days') . ':'); ?></strong> <?php echo e($packageInfo->package->number_of_days); ?></span></li>

                          <li><span><i class="fas fa-users"></i><strong><?php echo e(__('Maximum Persons') . ':'); ?></strong> <?php echo e($packageInfo->package->max_persons != null ? $packageInfo->package->max_persons : '-'); ?></span></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Package Section End -->
    <?php endif; ?>

    <?php if($sections->facilities_section == 1): ?>
    <!-- Why Choose Us/Facility Section Start -->
    <section class="wcu-section section-bg section-padding">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-5 offset-lg-1">
            <!-- Section Title -->
            <div class="feature-left">
              <div class="section-title">
                <?php if(!is_null($secHeading)): ?>
                  <span class="title-top with-border"><?php echo e(convertUtf8($secHeading->facility_section_title)); ?></span>
                  <h1><?php echo e(convertUtf8($secHeading->facility_section_subtitle)); ?></h1>
                <?php endif; ?>
              </div>

              <?php if(count($facilities) > 0): ?>
                <ul class="feature-list">
                  <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="wow fadeInUp animated" data-wow-duration="1000ms" data-wow-delay="<?php echo e($loop->iteration * 100); ?>ms">
                      <div class="feature-icon"><i class="<?php echo e($facility->facility_icon); ?>"></i></div>
                      <h4><?php echo e(convertUtf8($facility->facility_title)); ?></h4>
                      <p><?php echo e($facility->facility_text); ?></p>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-lg-6">
            <?php if(!is_null($secHeading)): ?>
              <div class="feature-img">
                <div class="feature-abs-con">
                  <div class="f-inner">
                    <i class="far fa-stars"></i>
                    <p><?php echo e(__('Popular Features')); ?></p>
                  </div>
                </div>
                <img class="lazy" data-src="<?php echo e(asset('assets/img/facility_section/' . $secHeading->facility_section_image)); ?>" alt="image">
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>
    <!-- Why Choose Us/Facility Section End -->
    <?php endif; ?>

    <?php if($sections->testimonials_section == 1): ?>
    <!-- Feedback Section Start -->
    <section class="feedback-section section-padding">
      <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center">
          <?php if(!empty($secHeading)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <span class="title-top"><?php echo e(convertUtf8($secHeading->testimonial_section_title)); ?></span>
                    <h1><?php echo e(convertUtf8($secHeading->testimonial_section_subtitle)); ?></h1>
                </div>
            </div>
          <?php endif; ?>
        </div>

        <?php if(count($testimonials) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3 class="text-white"><?php echo e(__('No Testimonial Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="feadback-slide" id="feedbackSlideActive">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-feedback-box">
                  <p><?php echo e($testimonial->comment); ?></p>
                  <h5 class="feedback-author"><?php echo e(convertUtf8($testimonial->client_name)); ?></h5>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Feedback Section End -->
    <?php endif; ?>

    <?php if($sections->brand_section == 1): ?>
    <!-- Brands Section Start -->
    <section class="brands-section primary-bg">
      <div class="container">
        <?php if(count($brands) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Brand Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div id="brandsSlideActive" class="row">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="brand-item text-center d-block" href="<?php echo e($brand->brand_url); ?>" target="_blank">
                  <img class="lazy" data-src="<?php echo e(asset('assets/img/brands/' . $brand->brand_img)); ?>" alt="brand image">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Brands Section End -->
    <?php endif; ?>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script src="<?php echo e(asset('assets/js/home.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/home/index_one.blade.php ENDPATH**/ ?>