<!DOCTYPE html>
<html <?php if($currentLanguageInfo->direction == 1): ?> dir="rtl" <?php endif; ?>>
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="<?php echo $__env->yieldContent('meta-description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta-keywords'); ?>">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title><?php echo $__env->yieldContent('pageHeading'); ?> | <?php echo e($websiteInfo->website_title); ?></title>

    
    <link
      rel="shortcut icon"
      type="image/png"
      href="<?php echo e(asset('assets/img/' . $websiteInfo->favicon)); ?>"
    >

    
    <?php if ($__env->exists('frontend.partials.styles')) echo $__env->make('frontend.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body>
    
    <?php if($websiteInfo->preloader_status == 1): ?>
    <div class="loader" id="preLoader">
      <img class="lazy" data-src="<?php echo e(asset('assets/img/' . $websiteInfo->preloader)); ?>" alt="">
    </div>
    <?php endif; ?>
    

    
    <header class="<?php if($websiteInfo->theme_version == 'theme_two'): ?> home-two <?php endif; ?>">

      
      <?php if($websiteInfo->theme_version == 'theme_one'): ?>
        
        <?php if ($__env->exists('frontend.partials.header_top_one')) echo $__env->make('frontend.partials.header_top_one', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if ($__env->exists('frontend.partials.header_nav_one')) echo $__env->make('frontend.partials.header_nav_one', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php elseif($websiteInfo->theme_version == 'theme_two'): ?>
        
        <?php if ($__env->exists('frontend.partials.header_top_two')) echo $__env->make('frontend.partials.header_top_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if ($__env->exists('frontend.partials.header_nav_two')) echo $__env->make('frontend.partials.header_nav_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
    </header>
    

    <?php echo $__env->yieldContent('content'); ?>

    
    <div class="back-top">
      <a href="#" class="back-to-top">
        <i class="far fa-angle-up"></i>
      </a>
    </div>
    


    
    <?php if ($__env->exists('frontend.partials.footer')) echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php if ($__env->exists('frontend.partials.popups')) echo $__env->make('frontend.partials.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    
    <div id="WAButton"></div>

    
    <?php if(!empty($cookie) && $cookie->cookie_alert_status == 1): ?>
    <div class="cookie">
        <?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php endif; ?>
    

    
    <?php if ($__env->exists('frontend.partials.scripts')) echo $__env->make('frontend.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->yieldContent('script'); ?>
  </body>
</html>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/installer/hotelia-2.1/core/resources/views/frontend/layout.blade.php ENDPATH**/ ?>