
<link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome-iconpicker.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/dropzone.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.dm-uploader.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-tagsinput.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery-ui.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.timepicker.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datepicker.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/daterangepicker.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote-bs4.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/atlantis.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/admin-main.css')); ?>">
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/partials/styles.blade.php ENDPATH**/ ?>