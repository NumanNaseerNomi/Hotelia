<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('New Booking')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Room Bookings')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('New Booking')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="card-title d-inline-block"><?php echo e(__('Make New Booking')); ?></div>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <form id="bookingForm" action="<?php echo e(route('admin.room_bookings.make_booking')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="room_id" value="<?php echo e(request()->input('room_id')); ?>">

                <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Check In / Out Date') . '*'); ?></label>
                      <input type="text" class="form-control" placeholder="<?php echo e(__('Select Dates')); ?>" id="date-range" name="dates" value="<?php echo e(old('dates')); ?>" readonly>
                      <?php $__errorArgs = ['dates'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Number of Nights') . '*'); ?></label>
                      <input type="text" class="form-control" placeholder="<?php echo e(__('Number of Nights')); ?>" id="night" name="nights" value="<?php echo e(old('nights')); ?>" readonly>
                      <?php $__errorArgs = ['nights'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      <p class="text-warning mt-1 mb-0 ml-1">
                        <?php echo e(__('Number of nights will be calculated based on checkin & checkout date.')); ?>

                      </p>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Number of Guests') . '*'); ?></label>
                      <input type="number" class="form-control" placeholder="<?php echo e(__('Enter Number of Guests')); ?>" name="guests" value="<?php echo e(old('guests')); ?>">
                      <?php $__errorArgs = ['guests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Subtotal') . ' (' . $currencyInfo->base_currency_text . ')'); ?></label>
                      <input type="text" class="form-control" name="subtotal" value="0.00" readonly id="subtotal">
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Discount') . ' (' . $currencyInfo->base_currency_text . ')'); ?></label>
                      <input type="text" class="form-control" name="discount" value="0.00" id="discount" placeholder="Enter Discount Amount" oninput="applyDiscount()">
                      <p class="text-warning mt-1 mb-0 ml-1">
                        <?php echo e(__('Do not press \'Enter\' key.')); ?>

                      </p>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Total Rent') . ' (' . $currencyInfo->base_currency_text . ')'); ?></label>
                      <input type="text" class="form-control" name="total" value="0.00" readonly id="total">
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Customer Full Name') . '*'); ?></label>
                      <input type="text" class="form-control" placeholder="<?php echo e(__('Enter Full Name')); ?>" name="customer_name" value="<?php echo e(old('customer_name')); ?>">
                      <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Customer Phone Number') . '*'); ?></label>
                      <input type="text" class="form-control" placeholder="<?php echo e(__('Enter Phone Number')); ?>" name="customer_phone" value="<?php echo e(old('customer_phone')); ?>">
                      <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Customer Email') . '*'); ?></label>
                      <input type="email" class="form-control" placeholder="<?php echo e(__('Enter Customer Email')); ?>" name="customer_email" value="<?php echo e(old('customer_email')); ?>">
                      <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Payment Method') . '*'); ?></label>
                      <select name="payment_method" class="form-control">
                        <option selected disabled><?php echo e(__('Select a Method')); ?></option>

                        <?php if(count($onlineGateways) > 0): ?>
                          <?php $__currentLoopData = $onlineGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onlineGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('payment_method') == $onlineGateway->name ? 'selected' : ''); ?> value="<?php echo e($onlineGateway->name); ?>">
                              <?php echo e($onlineGateway->name); ?>

                            </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if(count($offlineGateways) > 0): ?>
                          <?php $__currentLoopData = $offlineGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offlineGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('payment_method') == $offlineGateway->name ? 'selected' : ''); ?> value="<?php echo e($offlineGateway->name); ?>">
                              <?php echo e($offlineGateway->name); ?>

                            </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </select>
                      <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Payment Status') . '*'); ?></label>
                      <select name="payment_status" class="form-control">
                        <option selected disabled><?php echo e(__('Select Payment Status')); ?></option>
                        <option <?php echo e(old('payment_status') == '1' ? 'selected' : ''); ?> value="1">
                          <?php echo e(__('Paid')); ?>

                        </option>
                        <option <?php echo e(old('payment_status') == '0' ? 'selected' : ''); ?> value="0">
                          <?php echo e(__('Unpaid')); ?>

                        </option>
                      </select>
                      <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 mb-0 ml-1 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" form="bookingForm" class="btn btn-success">
                <?php echo e(__('Submit')); ?>

              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script>
    'use strict';

    // assign php value to js variable
    let bookedDates = <?php echo json_encode($dates); ?>;
    let roomRentPerNight = '<?php echo e($rent); ?>';
  </script>

  <script type="text/javascript" src="<?php echo e(asset('assets/js/admin-room.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/rooms/booking_form.blade.php ENDPATH**/ ?>