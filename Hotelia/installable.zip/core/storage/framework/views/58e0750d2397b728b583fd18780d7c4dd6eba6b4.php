<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Dashboard')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section
      class="breadcrumb-area d-flex align-items-center position-relative bg-img-center"
      style="background-image: url(<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>);"
    >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(__('Dashboard')); ?></h1>
          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>
            <li><?php echo e(__('Dashboard')); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Dashboard Area Start -->
    <section class="user-dashboard">
      <div class="container">
        <div class="row">
          <?php echo $__env->make('frontend.user.side_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="col-lg-9">
            <div class="row mb-5">
              <div class="col-lg-12">
                <div class="user-profile-details">
                  <div class="account-info">
                    <div class="title">
                      <h4><?php echo e(__('User Information')); ?></h4>
                    </div>

                    <div class="main-info">
                      <ul class="list">
                        <?php if(Auth::guard('web')->user()->first_name != null ||
                          Auth::guard('web')->user()->last_name != null): ?>
                          <li><span><?php echo e(__('Name') . ':'); ?></span></li>
                        <?php endif; ?>

                        <li><span><?php echo e(__('Username') . ':'); ?></span></li>

                        <li><span><?php echo e(__('Email') . ':'); ?></span></li>

                        <?php if(Auth::guard('web')->user()->contact_number != null): ?>
                          <li><span><?php echo e(__('Phone') . ':'); ?></span></li>
                        <?php endif; ?>

                        <?php if(Auth::guard('web')->user()->address != null): ?>
                          <li><span><?php echo e(__('Address') . ':'); ?></span></li>
                        <?php endif; ?>

                        <?php if(Auth::guard('web')->user()->city != null): ?>
                          <li><span><?php echo e(__('City') . ':'); ?></span></li>
                        <?php endif; ?>

                        <?php if(Auth::guard('web')->user()->state != null): ?>
                          <li><span><?php echo e(__('State') . ':'); ?></span></li>
                        <?php endif; ?>

                        <?php if(Auth::guard('web')->user()->country != null): ?>
                          <li><span><?php echo e(__('Country') . ':'); ?></span></li>
                        <?php endif; ?>
                      </ul>

                      <ul class="list">
                        <li>
                          <?php echo e(Auth::guard('web')->user()->first_name . ' ' . Auth::guard('web')->user()->last_name); ?>

                        </li>

                        <li>
                          <?php echo e(Auth::guard('web')->user()->username); ?>

                        </li>

                        <li>
                          <?php echo e(Auth::guard('web')->user()->email); ?>

                        </li>

                        <li>
                          <?php echo e(Auth::guard('web')->user()->contact_number); ?>

                        </li>

                        <li>
                          <?php echo e(Auth::guard('web')->user()->address); ?>

                        </li>

                        <li>
                          <?php echo e(Auth::guard('web')->user()->city); ?>

                        </li>

                        <li>
                          <?php echo e(Auth::guard('web')->user()->state); ?>

                        </li>

                        <li>
                          <?php echo e(Auth::guard('web')->user()->country); ?>

                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <div class="card card-box box-1">
                  <div class="card-info">
                    <h5><?php echo e(__('Total Room Booking')); ?></h5>
                    <p><?php echo e($totalRoomBooking); ?></p>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="card card-box box-2">
                  <div class="card-info">
                    <h5><?php echo e(__('Total Package Booking')); ?></h5>
                    <p><?php echo e($totalPackageBooking); ?></p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Dashboard Area End -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/user/dashboard.blade.php ENDPATH**/ ?>