<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Payment Success')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section
      class="breadcrumb-area d-flex align-items-center position-relative bg-img-center"
      style="background-image: url(<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>);"
    >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(__('Success')); ?></h1>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    
    <div class="purchase-message">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="purchase-success">
              <div class="icon text-success"><i class="far fa-check-circle"></i></div>
              <h2><?php echo e(__('Success') . '!'); ?></h2>
              <?php if(request()->input('type') == 'offline'): ?>
                <p><?php echo e(__('We have received your booking request.')); ?></p>
              <?php else: ?>
                <p><?php echo e(__('Your transaction was successful.')); ?></p>
              <?php endif; ?>

              <p><?php echo e(__('We have sent you a mail with an invoice.')); ?></p>

              <?php if(request()->input('type') == 'offline'): ?>
                <p><?php echo e(__('You will be notified via mail once it is approved.')); ?></p>
              <?php endif; ?>
              <p class="mt-4"><?php echo e(__('Thank You.')); ?></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/partials/payment_success.blade.php ENDPATH**/ ?>