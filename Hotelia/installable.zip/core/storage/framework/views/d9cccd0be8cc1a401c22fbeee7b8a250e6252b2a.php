<div class="header-top-area section-bg">
    <div class="container-fluid">
      <div class="row align-items-center">
        <div class="col-xl-4 col-lg-7 offset-xl-3 col-md-6 d-md-block d-none">
          <ul class="top-contact-info list-inline">
            <?php if(!is_null($websiteInfo->address)): ?>
              <li><i class="far fa-map-marker-alt"></i><?php echo e($websiteInfo->address); ?></li>
            <?php endif; ?>

            <?php if(!is_null($websiteInfo->support_contact)): ?>
              <li><i class="far fa-phone"></i><?php echo e($websiteInfo->support_contact); ?></li>
            <?php endif; ?>
          </ul>
        </div>

        <div class="col-xl-5 col-lg-5 col-md-6">
          <div class="top-right">
            <ul class="top-menu list-inline d-inline">
              <?php if(auth()->guard('web')->guest()): ?>
                <li><a href="<?php echo e(route('user.login')); ?>"><i class="fas fa-sign-in-alt <?php echo e($currentLanguageInfo->direction == 0 ? 'mr-2' : 'ml-2'); ?>"></i><?php echo e(__('Login')); ?></a></li>
                <li><a href="<?php echo e(route('user.signup')); ?>"><i class="fas fa-user-plus <?php echo e($currentLanguageInfo->direction == 0 ? 'mr-2' : 'ml-2'); ?>"></i><?php echo e(__('Signup')); ?></a></li>
              <?php endif; ?>

              <?php if(auth()->guard('web')->check()): ?>
                <li><a href="<?php echo e(route('user.dashboard')); ?>"><i class="far fa-user <?php echo e($currentLanguageInfo->direction == 0 ? 'mr-2' : 'ml-2'); ?>"></i><?php echo e(__('Dashboard')); ?></a></li>
                <li><a href="<?php echo e(route('user.logout')); ?>"><i class="fas fa-sign-out-alt <?php echo e($currentLanguageInfo->direction == 0 ? 'mr-2' : 'ml-2'); ?>"></i><?php echo e(__('Logout')); ?></a></li>
              <?php endif; ?>
            </ul>

            <?php if(count($socialLinkInfos) > 0): ?>
              <ul class="top-social-icon list-inline d-md-inline-block d-none">
                <?php $__currentLoopData = $socialLinkInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialLinkInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <a href="<?php echo e($socialLinkInfo->url); ?>"><i class="<?php echo e($socialLinkInfo->icon); ?>"></i></a>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/installer/hotelia-2.1/core/resources/views/frontend/partials/header_top_one.blade.php ENDPATH**/ ?>