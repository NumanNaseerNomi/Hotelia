<!DOCTYPE html>
<html>
  <head>
    
    <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta
      name='viewport'
      content='width=device-width, initial-scale=1.0, shrink-to-fit=no'
    >

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title><?php echo e('Admin | ' . $websiteInfo->website_title); ?></title>

    
    <link
      rel="shortcut icon"
      type="image/png"
      href="<?php echo e(asset('assets/img/' . $websiteInfo->favicon)); ?>"
    >

    
    <?php if ($__env->exists('backend.partials.styles')) echo $__env->make('backend.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->yieldContent('style'); ?>
  </head>

  <body <?php if(request()->cookie('admin-theme') == 'dark'): ?> data-background-color="dark" <?php endif; ?>>
    
    <div class="request-loader">
      <img src="<?php echo e(asset('assets/img/loader.gif')); ?>" alt="loader">
    </div>
    

    <div class="wrapper
    <?php if(request()->routeIs('admin.file-manager')): ?>
    overlay-sidebar
    <?php endif; ?>">
      
      <?php if ($__env->exists('backend.partials.top_navbar')) echo $__env->make('backend.partials.top_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

      
      <?php if ($__env->exists('backend.partials.side_navbar')) echo $__env->make('backend.partials.side_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

      <div class="main-panel">
        <div class="content">
          <div class="page-inner">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
        </div>

        
        <?php if ($__env->exists('backend.partials.footer')) echo $__env->make('backend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
      </div>
    </div>

    <!-- LFM Modal -->
    <div class="modal fade lfm-modal" id="lfmModalSummernote" tabindex="-1" role="dialog" aria-labelledby="lfmModalSummernoteTitle" aria-hidden="true">
      <i class="fas fa-times-circle"></i>

      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-body p-0">
            <iframe src="" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
          </div>
        </div>
      </div>
    </div>

    
    <?php if ($__env->exists('backend.partials.scripts')) echo $__env->make('backend.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->yieldContent('script'); ?>
  </body>
</html>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/layout.blade.php ENDPATH**/ ?>