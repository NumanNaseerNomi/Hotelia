<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Edit Profile')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section
      class="breadcrumb-area d-flex align-items-center position-relative bg-img-center"
      style="background-image: url(<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>);"
    >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(__('Edit Profile')); ?></h1>
          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>
            <li><?php echo e(__('Edit Profile')); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Edit Profile Area Start -->
    <section class="user-dashboard">
      <div class="container">
        <div class="row">
          <?php echo $__env->make('frontend.user.side_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="col-lg-9">
            <div class="row mb-5">
              <div class="col-lg-12">
                <div class="user-profile-details">
                  <div class="account-info">
                    <div class="title">
                      <h4><?php echo e(__('Edit Profile')); ?></h4>
                    </div>

                    <div class="edit-info-area">
                      <form action="<?php echo e(route('user.update_profile')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($userInfo->id); ?>">

                        <div class="upload-img">
                          <div class="img-box">
                            <img
                              src="<?php echo e(is_null($userInfo->image) ? asset('assets/img/user-profile.jpg') : asset('assets/img/users/' . $userInfo->image)); ?>"
                              alt="user image"
                              class="user-photo"
                            >
                          </div>

                          <div class="file-upload-area">
                            <div class="upload-file">
                              <input type="file" accept=".jpg, .jpeg, .png" name="user_image" class="upload">
                              <span><?php echo e(__('Upload')); ?></span>
                            </div>
                          </div>
                          <?php $__errorArgs = ['user_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                          <div class="col-lg-6">
                            <input type="text" class="form_control" placeholder="<?php echo e(__('First Name')); ?>" name="first_name" value="<?php echo e($userInfo->first_name); ?>">
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-6">
                            <input type="text" class="form_control" placeholder="<?php echo e(__('Last Name')); ?>" name="last_name" value="<?php echo e($userInfo->last_name); ?>">
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-6">
                            <input type="email" class="form_control" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e($userInfo->email); ?>" readonly>
                          </div>

                          <div class="col-lg-6">
                            <input type="text" class="form_control" placeholder="<?php echo e(__('Username')); ?>" name="username" value="<?php echo e($userInfo->username); ?>">
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-12">
                            <input type="text" class="form_control" placeholder="<?php echo e(__('Contact Number')); ?>" name="contact_number" value="<?php echo e($userInfo->contact_number); ?>">
                            <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-12">
                            <textarea class="form_control" placeholder="<?php echo e(__('Address')); ?>" name="address"><?php echo e($userInfo->address); ?></textarea>
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-6">
                            <input type="text" class="form_control" placeholder="<?php echo e(__('City')); ?>" name="city" value="<?php echo e($userInfo->city); ?>">
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-6">
                            <input type="text" class="form_control" placeholder="<?php echo e(__('State')); ?>" name="state" value="<?php echo e($userInfo->state); ?>">
                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-12">
                            <input type="text" class="form_control" placeholder="<?php echo e(__('Country')); ?>" name="country" value="<?php echo e($userInfo->country); ?>">
                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="mb-3 ml-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="col-lg-12">
                            <div class="form-button">
                              <button class="btn form-btn"><?php echo e(__('Submit')); ?></button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Edit Profile Area End -->
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script src="<?php echo e(asset('assets/js/admin-profile.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/frontend/user/edit_profile.blade.php ENDPATH**/ ?>