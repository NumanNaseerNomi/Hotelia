<div class="sidebar sidebar-style-2" <?php if(request()->cookie('admin-theme') == 'dark'): ?> data-background-color="dark2" <?php endif; ?>>
  <div class="sidebar-wrapper scrollbar scrollbar-inner">
    <div class="sidebar-content">
      <div class="user">
        <div class="avatar-sm float-left mr-2">
          <?php if(Auth::guard('admin')->user()->image != null): ?>
            <img src="<?php echo e(asset('assets/img/admins/' . Auth::guard('admin')->user()->image)); ?>" alt="Admin Image" class="avatar-img rounded-circle">
          <?php else: ?>
            <img src="<?php echo e(asset('assets/img/blank_user.jpg')); ?>" alt="Admin Image" class="avatar-img rounded-circle">
          <?php endif; ?>
        </div>
        <div class="info">
          <a data-toggle="collapse" href="#adminProfileMenu" aria-expanded="true">
            <span>
              <?php echo e(Auth::guard('admin')->user()->first_name); ?>

              <span class="caret"></span>
            </span>
          </a>
          <div class="clearfix"></div>
          <div class="collapse in" id="adminProfileMenu">
            <ul class="nav">
              <li>
                <a href="<?php echo e(route('admin.edit_profile')); ?>">
                  <span class="link-collapse"><?php echo e(__('Edit Profile')); ?></span>
                </a>
              </li>
              <li>
                <a href="<?php echo e(route('admin.change_password')); ?>">
                  <span class="link-collapse"><?php echo e(__('Change Password')); ?></span>
                </a>
              </li>
              <li>
                <a href="<?php echo e(route('admin.logout')); ?>">
                  <span class="link-collapse"><?php echo e(__('Logout')); ?></span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <ul class="nav nav-primary mt-0">
        <div class="row mb-2">
          <div class="col-12">
            <form action="">
              <div class="form-group py-0">
                <input name="term" type="text" class="form-control sidebar-search ltr" placeholder="Search Menu Here...">
              </div>
            </form>
          </div>
        </div>

        
        <li class="nav-item <?php if(request()->routeIs('admin.dashboard')): ?> active <?php endif; ?>">
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="la flaticon-paint-palette"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Rooms Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.rooms_management.settings')): ?> active
            <?php elseif(request()->routeIs('admin.rooms_management.coupons')): ?> active
            <?php elseif(request()->routeIs('admin.rooms_management.amenities')): ?> active
            <?php elseif(request()->routeIs('admin.rooms_management.categories')): ?> active
            <?php elseif(request()->routeIs('admin.rooms_management.rooms')): ?> active
            <?php elseif(request()->routeIs('admin.rooms_management.create_room')): ?> active
            <?php elseif(request()->routeIs('admin.rooms_management.edit_room')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#rooms">
              <i class="fal fa-home"></i>
              <p class="pr-2"><?php echo e(__('Rooms Management')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="rooms" class="collapse
              <?php if(request()->routeIs('admin.rooms_management.settings')): ?> show
              <?php elseif(request()->routeIs('admin.rooms_management.coupons')): ?> show
              <?php elseif(request()->routeIs('admin.rooms_management.amenities')): ?> show
              <?php elseif(request()->routeIs('admin.rooms_management.categories')): ?> show
              <?php elseif(request()->routeIs('admin.rooms_management.rooms')): ?> show
              <?php elseif(request()->routeIs('admin.rooms_management.create_room')): ?> show
              <?php elseif(request()->routeIs('admin.rooms_management.edit_room')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.rooms_management.settings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.rooms_management.settings')); ?>">
                    <span class="sub-item"><?php echo e(__('Settings')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.rooms_management.coupons') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.rooms_management.coupons')); ?>">
                    <span class="sub-item"><?php echo e(__('Coupons')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.rooms_management.amenities') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.rooms_management.amenities') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item">Amenities</span>
                  </a>
                </li>
                <?php if($websiteInfo->room_category_status == 1): ?>
                  <li class="<?php echo e(request()->routeIs('admin.rooms_management.categories') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.rooms_management.categories') . '?language=' . $defaultLang->code); ?>">
                      <span class="sub-item"><?php echo e(__('Categories')); ?></span>
                    </a>
                  </li>
                <?php endif; ?>
                <li class="<?php if(request()->routeIs('admin.rooms_management.rooms')): ?> active
                  <?php elseif(request()->routeIs('admin.rooms_management.create_room')): ?> active
                  <?php elseif(request()->routeIs('admin.rooms_management.edit_room')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.rooms_management.rooms')); ?>">
                    <span class="sub-item">Rooms</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Room Bookings', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.room_bookings.all_bookings')): ?> active
            <?php elseif(request()->routeIs('admin.room_bookings.paid_bookings')): ?> active
            <?php elseif(request()->routeIs('admin.room_bookings.unpaid_bookings')): ?> active
            <?php elseif(request()->routeIs('admin.room_bookings.booking_details_and_edit')): ?> active
            <?php elseif(request()->routeIs('admin.room_bookings.booking_form')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#roomBookings">
              <i class="far fa-calendar-check"></i>
              <p class="pr-2">Room Bookings</p>
              <span class="caret"></span>
            </a>
            <div id="roomBookings" class="collapse
              <?php if(request()->routeIs('admin.room_bookings.all_bookings')): ?> show
              <?php elseif(request()->routeIs('admin.room_bookings.paid_bookings')): ?> show
              <?php elseif(request()->routeIs('admin.room_bookings.unpaid_bookings')): ?> show
              <?php elseif(request()->routeIs('admin.room_bookings.booking_details_and_edit')): ?> show
              <?php elseif(request()->routeIs('admin.room_bookings.booking_form')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.room_bookings.all_bookings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.room_bookings.all_bookings')); ?>">
                    <span class="sub-item"><?php echo e(__('All Bookings')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.room_bookings.paid_bookings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.room_bookings.paid_bookings')); ?>">
                    <span class="sub-item"><?php echo e(__('Paid Bookings')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.room_bookings.unpaid_bookings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.room_bookings.unpaid_bookings')); ?>">
                    <span class="sub-item"><?php echo e(__('Unpaid Bookings')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Packages Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.packages_management.settings')): ?> active
            <?php elseif(request()->routeIs('admin.packages_management.coupons')): ?> active
            <?php elseif(request()->routeIs('admin.packages_management.categories')): ?> active
            <?php elseif(request()->routeIs('admin.packages_management.packages')): ?> active
            <?php elseif(request()->routeIs('admin.packages_management.create_package')): ?> active
            <?php elseif(request()->routeIs('admin.packages_management.edit_package')): ?> active
            <?php elseif(request()->routeIs('admin.packages_management.view_locations')): ?> active
            <?php elseif(request()->routeIs('admin.packages_management.view_plans')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#packages">
              <i class="fal fa-box-alt"></i>
              <p><?php echo e(__('Packages Management')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="packages" class="collapse
              <?php if(request()->routeIs('admin.packages_management.settings')): ?> show
              <?php elseif(request()->routeIs('admin.packages_management.coupons')): ?> show
              <?php elseif(request()->routeIs('admin.packages_management.categories')): ?> show
              <?php elseif(request()->routeIs('admin.packages_management.packages')): ?> show
              <?php elseif(request()->routeIs('admin.packages_management.create_package')): ?> show
              <?php elseif(request()->routeIs('admin.packages_management.edit_package')): ?> show
              <?php elseif(request()->routeIs('admin.packages_management.view_locations')): ?> show
              <?php elseif(request()->routeIs('admin.packages_management.view_plans')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.packages_management.settings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.packages_management.settings')); ?>">
                    <span class="sub-item"><?php echo e(__('Settings')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.packages_management.coupons') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.packages_management.coupons')); ?>">
                    <span class="sub-item"><?php echo e(__('Coupons')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.packages_management.categories') ? 'active' : ''); ?> <?php echo e($settings->package_category_status == 1 ? '' : 'd-none'); ?>">
                  <a href="<?php echo e(route('admin.packages_management.categories') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Categories')); ?></span>
                  </a>
                </li>
                <li class="<?php if(request()->routeIs('admin.packages_management.packages')): ?> active
                  <?php elseif(request()->routeIs('admin.packages_management.create_package')): ?> active
                  <?php elseif(request()->routeIs('admin.packages_management.edit_package')): ?> active
                  <?php elseif(request()->routeIs('admin.packages_management.view_locations')): ?> active
                  <?php elseif(request()->routeIs('admin.packages_management.view_plans')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.packages_management.packages')); ?>">
                    <span class="sub-item"><?php echo e(__('Packages')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Package Bookings', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.package_bookings.all_bookings')): ?> active
            <?php elseif(request()->routeIs('admin.package_bookings.paid_bookings')): ?> active
            <?php elseif(request()->routeIs('admin.package_bookings.unpaid_bookings')): ?> active 
            <?php elseif(request()->routeIs('admin.package_bookings.booking_details')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#packageBookings">
              <i class="far fa-calendar-check"></i>
              <p>Package Bookings</p>
              <span class="caret"></span>
            </a>
            <div id="packageBookings" class="collapse
              <?php if(request()->routeIs('admin.package_bookings.all_bookings')): ?> show
              <?php elseif(request()->routeIs('admin.package_bookings.paid_bookings')): ?> show
              <?php elseif(request()->routeIs('admin.package_bookings.unpaid_bookings')): ?> show 
              <?php elseif(request()->routeIs('admin.package_bookings.booking_details')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.package_bookings.all_bookings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.package_bookings.all_bookings')); ?>">
                    <span class="sub-item"><?php echo e(__('All Bookings')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.package_bookings.paid_bookings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.package_bookings.paid_bookings')); ?>">
                    <span class="sub-item"><?php echo e(__('Paid Bookings')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.package_bookings.unpaid_bookings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.package_bookings.unpaid_bookings')); ?>">
                    <span class="sub-item"><?php echo e(__('Unpaid Bookings')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>


        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Home Page Sections', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.home_page.hero.static_version')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.hero.slider_version')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.hero.create_slider')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.hero.edit_slider')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.hero.video_version')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.intro_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.intro_section.create_count_info')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.intro_section.edit_count_info')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.room_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.service_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.booking_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.package_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.facility_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.facility_section.create_facility')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.facility_section.edit_facility')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.testimonial_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.testimonial_section.create_testimonial')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.testimonial_section.edit_testimonial')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.brand_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.faq_section')): ?> active
            <?php elseif(request()->routeIs('admin.home_page.blog_section')): ?> active
            <?php elseif(request()->routeIs('admin.sections.index')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#home_page">
              <i class="fal fa-layer-group"></i>
              <p><?php echo e(__('Home Page Sections')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="home_page" class="collapse
              <?php if(request()->routeIs('admin.home_page.hero.static_version')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.hero.slider_version')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.hero.create_slider')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.hero.edit_slider')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.hero.video_version')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.intro_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.intro_section.create_count_info')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.intro_section.edit_count_info')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.room_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.service_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.booking_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.package_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.facility_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.facility_section.create_facility')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.facility_section.edit_facility')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.testimonial_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.testimonial_section.create_testimonial')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.testimonial_section.edit_testimonial')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.brand_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.faq_section')): ?> show
              <?php elseif(request()->routeIs('admin.home_page.blog_section')): ?> show
              <?php elseif(request()->routeIs('admin.sections.index')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="submenu">
                  <a data-toggle="collapse" href="#hero_section">
                    <span class="sub-item"><?php echo e(__('Hero Section')); ?></span>
                    <span class="caret"></span>
                  </a>
                  <div id="hero_section" class="collapse
                    <?php if(request()->routeIs('admin.home_page.hero.static_version')): ?> show
                    <?php elseif(request()->routeIs('admin.home_page.hero.slider_version')): ?> show
                    <?php elseif(request()->routeIs('admin.home_page.hero.create_slider')): ?> show
                    <?php elseif(request()->routeIs('admin.home_page.hero.edit_slider')): ?> show
                    <?php elseif(request()->routeIs('admin.home_page.hero.video_version')): ?> show <?php endif; ?>"
                  >
                    <ul class="nav nav-collapse subnav">
                      <li class="<?php echo e(request()->routeIs('admin.home_page.hero.static_version') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.home_page.hero.static_version') . '?language=' . $defaultLang->code); ?>">
                          <span class="sub-item"><?php echo e(__('Static Version')); ?></span>
                        </a>
                      </li>
                      <li class="<?php if(request()->routeIs('admin.home_page.hero.slider_version')): ?> active
                        <?php elseif(request()->routeIs('admin.home_page.hero.create_slider')): ?> active
                        <?php elseif(request()->routeIs('admin.home_page.hero.edit_slider')): ?> active <?php endif; ?>"
                      >
                        <a href="<?php echo e(route('admin.home_page.hero.slider_version') . '?language=' . $defaultLang->code); ?>">
                          <span class="sub-item"><?php echo e(__('Slider Version')); ?></span>
                        </a>
                      </li>
                      <li class="<?php echo e(request()->routeIs('admin.home_page.hero.video_version') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.home_page.hero.video_version') . '?language=' . $defaultLang->code); ?>">
                          <span class="sub-item"><?php echo e(__('Video Version')); ?></span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </li>
                <li class="<?php if(request()->routeIs('admin.home_page.intro_section')): ?> active
                  <?php elseif(request()->routeIs('admin.home_page.intro_section.create_count_info')): ?> active
                  <?php elseif(request()->routeIs('admin.home_page.intro_section.edit_count_info')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.home_page.intro_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Intro & Counter Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.home_page.room_section') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.home_page.room_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Room Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.home_page.service_section') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.home_page.service_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Service Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.home_page.booking_section') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.home_page.booking_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Video Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.home_page.package_section') ? 'active' : ''); ?> <?php echo e($websiteInfo->theme_version == 'theme_one' ? '' : 'd-none'); ?>">
                  <a href="<?php echo e(route('admin.home_page.package_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Package Section')); ?></span>
                  </a>
                </li>
                <li class="<?php if(request()->routeIs('admin.home_page.facility_section')): ?> active
                  <?php elseif(request()->routeIs('admin.home_page.facility_section.create_facility')): ?> active
                  <?php elseif(request()->routeIs('admin.home_page.facility_section.edit_facility')): ?> active
                  <?php endif; ?> <?php echo e($websiteInfo->theme_version == 'theme_one' ? '' : 'd-none'); ?>"
                >
                  <a href="<?php echo e(route('admin.home_page.facility_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Facility Section')); ?></span>
                  </a>
                </li>
                <li class="<?php if(request()->routeIs('admin.home_page.testimonial_section')): ?> active
                  <?php elseif(request()->routeIs('admin.home_page.testimonial_section.create_testimonial')): ?> active
                  <?php elseif(request()->routeIs('admin.home_page.testimonial_section.edit_testimonial')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.home_page.testimonial_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Testimonial Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.home_page.brand_section') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.home_page.brand_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Brand Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.home_page.faq_section') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.home_page.faq_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('FAQ Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.home_page.blog_section') ? 'active' : ''); ?> <?php echo e($websiteInfo->theme_version == 'theme_two' ? '' : 'd-none'); ?>">
                  <a href="<?php echo e(route('admin.home_page.blog_section') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Blog Section')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.sections.index') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.sections.index')); ?>">
                    <span class="sub-item"><?php echo e(__('Sections Hide / Show')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Footer', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.footer.text')): ?> active
            <?php elseif(request()->routeIs('admin.footer.quick_links')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#footer">
              <i class="fal fa-shoe-prints"></i>
              <p><?php echo e(__('Footer')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="footer" class="collapse
              <?php if(request()->routeIs('admin.footer.text')): ?> show
              <?php elseif(request()->routeIs('admin.footer.quick_links')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.footer.text') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.footer.text') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Footer Text')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.footer.quick_links') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.footer.quick_links') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item">Quick Links</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>


        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Services Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.services_management')): ?> active
            <?php elseif(request()->routeIs('admin.services_management.create_service')): ?> active
            <?php elseif(request()->routeIs('admin.services_management.edit_service')): ?> active <?php endif; ?>"
          >
            <a href="<?php echo e(route('admin.services_management')); ?>">
              <i class="fal fa-concierge-bell"></i>
              <p><?php echo e(__('Services Management')); ?></p>
            </a>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Blogs Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.blogs_management.categories')): ?> active
            <?php elseif(request()->routeIs('admin.blogs_management.blogs')): ?> active
            <?php elseif(request()->routeIs('admin.blogs_management.create_blog')): ?> active
            <?php elseif(request()->routeIs('admin.blogs_management.edit_blog')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#blogs">
              <i class="la flaticon-chat-4"></i>
              <p><?php echo e(__('Blogs Management')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="blogs" class="collapse
              <?php if(request()->routeIs('admin.blogs_management.categories')): ?> show
              <?php elseif(request()->routeIs('admin.blogs_management.blogs')): ?> show
              <?php elseif(request()->routeIs('admin.blogs_management.create_blog')): ?> show
              <?php elseif(request()->routeIs('admin.blogs_management.edit_blog')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.blogs_management.categories') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.blogs_management.categories') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Categories')); ?></span>
                  </a>
                </li>
                <li class="<?php if(request()->routeIs('admin.blogs_management.blogs')): ?> active
                  <?php elseif(request()->routeIs('admin.blogs_management.create_blog')): ?> active
                  <?php elseif(request()->routeIs('admin.blogs_management.edit_blog')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.blogs_management.blogs')); ?>">
                    <span class="sub-item">Blogs</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Gallery Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.gallery_management.categories')): ?> active
            <?php elseif(request()->routeIs('admin.gallery_management.images')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#gallery">
              <i class="la flaticon-picture"></i>
              <p><?php echo e(__('Gallery Management')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="gallery" class="collapse
              <?php if(request()->routeIs('admin.gallery_management.categories')): ?> show
              <?php elseif(request()->routeIs('admin.gallery_management.images')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.gallery_management.categories') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.gallery_management.categories') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Categories')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.gallery_management.images') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.gallery_management.images') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Images')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('FAQ Management', $permissions))): ?>
          
          <li class="nav-item <?php echo e(request()->routeIs('admin.faq_management') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.faq_management') . '?language=' . $defaultLang->code); ?>">
              <i class="la flaticon-round"></i>
              <p><?php echo e(__('FAQ Management')); ?></p>
            </a>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Custom Pages', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->path() == 'admin/page/create'): ?> active
            <?php elseif(request()->path() == 'admin/pages'): ?> active
            <?php elseif(request()->path() == 'admin/page/paren/link'): ?> active
            <?php elseif(request()->is('admin/page/*/edit')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#pages">
              <i class="la flaticon-file"></i>
              <p>Custom Pages</p>
              <span class="caret"></span>
            </a>
            <div class="collapse
              <?php if(request()->path() == 'admin/page/create'): ?> show
              <?php elseif(request()->path() == 'admin/pages'): ?> show
              <?php elseif(request()->is('admin/page/*/edit')): ?> show
              <?php elseif(request()->path() == 'admin/page/paren/link'): ?> show
              <?php endif; ?>" id="pages"
            >
              <ul class="nav nav-collapse">
                <li class="<?php if(request()->path() == 'admin/page/create'): ?> active <?php endif; ?>">
                  <a href="<?php echo e(route('admin.page.create')); ?>">
                    <span class="sub-item">Create Page</span>
                  </a>
                </li>
                <li class="<?php if(request()->path() == 'admin/pages'): ?> active
                  <?php elseif(request()->is('admin/page/*/edit')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.page.index')); ?>">
                    <span class="sub-item">Pages</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        
        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Announcement Popup', $permissions))): ?>
          <li class="nav-item <?php if(request()->path() == 'admin/popup/create'): ?> active
            <?php elseif(request()->path() == 'admin/popup/types'): ?> active
            <?php elseif(request()->is('admin/popup/*/edit')): ?> active
            <?php elseif(request()->path() == 'admin/popups'): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#announcementPopup">
              <i class="fas fa-bullhorn"></i>
              <p>Announcement Popup</p>
              <span class="caret"></span>
            </a>
            <div class="collapse
              <?php if(request()->path() == 'admin/popup/create'): ?> show
              <?php elseif(request()->path() == 'admin/popup/types'): ?> show
              <?php elseif(request()->path() == 'admin/popups'): ?> show
              <?php elseif(request()->is('admin/popup/*/edit')): ?> show
              <?php endif; ?>" id="announcementPopup"
            >
              <ul class="nav nav-collapse">
                <li class="<?php if(request()->path() == 'admin/popup/types'): ?> active
                  <?php elseif(request()->path() == 'admin/popup/create'): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.popup.types')); ?>">
                    <span class="sub-item">Add Popup</span>
                  </a>
                </li>
                <li class="<?php if(request()->path() == 'admin/popups'): ?> active
                  <?php elseif(request()->is('admin/popup/*/edit')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.popup.index') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item">Popups</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Users Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.register.user')): ?> active
            <?php elseif(request()->routeIs('register.user.view')): ?> active
            <?php elseif(request()->routeIs('register.user.changePass')): ?> active
            <?php elseif(request()->path() == 'admin/pushnotification/settings'): ?> active
            <?php elseif(request()->path() == 'admin/pushnotification/send'): ?> active
            <?php elseif(request()->path() == 'admin/subscribers'): ?> active
            <?php elseif(request()->path() == 'admin/mailsubscriber'): ?> active 
            <?php elseif(request()->routeIs('admin.user_management.push_notification.settings')): ?> active
            <?php elseif(request()->routeIs('admin.user_management.push_notification.notification_for_visitors')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#usersManagement">
              <i class="la flaticon-users"></i>
              <p>Users Management</p>
              <span class="caret"></span>
            </a>
            <div class="collapse
              <?php if(request()->routeIs('admin.register.user')): ?> show
              <?php elseif(request()->routeIs('register.user.view')): ?> show
              <?php elseif(request()->routeIs('register.user.changePass')): ?> show
              <?php elseif(request()->path() == 'admin/pushnotification/settings'): ?> show
              <?php elseif(request()->path() == 'admin/pushnotification/send'): ?> show
              <?php elseif(request()->path() == 'admin/subscribers'): ?> show
              <?php elseif(request()->path() == 'admin/mailsubscriber'): ?> show
              <?php elseif(request()->routeIs('admin.user_management.push_notification.settings')): ?> show
              <?php elseif(request()->routeIs('admin.user_management.push_notification.notification_for_visitors')): ?> show
              <?php endif; ?>" id="usersManagement"
            >
              <ul class="nav nav-collapse">
                
                <li class="<?php if(request()->routeIs('admin.register.user')): ?> active
                  <?php elseif(request()->routeIs('register.user.view')): ?> active
                  <?php elseif(request()->routeIs('register.user.changePass')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.register.user')); ?>">
                    <span class="sub-item">Registered Users</span>
                  </a>
                </li>
                
                <li class="<?php if(request()->path() == 'admin/subscribers'): ?> selected
                  <?php elseif(request()->path() == 'admin/mailsubscriber'): ?> selected <?php endif; ?>"
                >
                  <a data-toggle="collapse" href="#subscribers">
                    <span class="sub-item">Subscribers</span>
                    <span class="caret"></span>
                  </a>
                  <div class="collapse
                    <?php if(request()->path() == 'admin/subscribers'): ?> show
                    <?php elseif(request()->path() == 'admin/mailsubscriber'): ?> show
                    <?php endif; ?>" id="subscribers"
                  >
                    <ul class="nav nav-collapse subnav">
                      <li class="<?php if(request()->path() == 'admin/subscribers'): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('admin.subscriber.index')); ?>">
                          <span class="sub-item">Subscribers</span>
                        </a>
                      </li>
                      <li class="<?php if(request()->path() == 'admin/mailsubscriber'): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('admin.mailsubscriber')); ?>">
                          <span class="sub-item">Mail to Subscribers</span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </li>
                
                <li class="submenu">
                  <a data-toggle="collapse" href="#push_notification">
                    <span class="sub-item"><?php echo e(__('Push Notification')); ?></span>
                    <span class="caret"></span>
                  </a>

                  <div id="push_notification" class="collapse 
                    <?php if(request()->routeIs('admin.user_management.push_notification.settings')): ?> show 
                    <?php elseif(request()->routeIs('admin.user_management.push_notification.notification_for_visitors')): ?> show <?php endif; ?>"
                  >
                    <ul class="nav nav-collapse subnav">
                      <li class="<?php echo e(request()->routeIs('admin.user_management.push_notification.settings') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.user_management.push_notification.settings')); ?>">
                          <span class="sub-item"><?php echo e(__('Settings')); ?></span>
                        </a>
                      </li>

                      <li class="<?php echo e(request()->routeIs('admin.user_management.push_notification.notification_for_visitors') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.user_management.push_notification.notification_for_visitors')); ?>">
                          <span class="sub-item"><?php echo e(__('Send Notification')); ?></span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Payment Gateways', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.payment_gateways.online_gateways')): ?> active
            <?php elseif(request()->routeIs('admin.payment_gateways.offline_gateways')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#payment_gateways">
              <i class="la flaticon-paypal"></i>
              <p><?php echo e(__('Payment Gateways')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="payment_gateways" class="collapse
              <?php if(request()->routeIs('admin.payment_gateways.online_gateways')): ?> show
              <?php elseif(request()->routeIs('admin.payment_gateways.offline_gateways')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.payment_gateways.online_gateways') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.payment_gateways.online_gateways')); ?>">
                    <span class="sub-item"><?php echo e(__('Online Gateways')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.payment_gateways.offline_gateways') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.payment_gateways.offline_gateways')); ?>">
                    <span class="sub-item"><?php echo e(__('Offline Gateways')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Theme & Home', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.theme.version')): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.theme.version')); ?>">
              <i class="la flaticon-file"></i>
              <p><?php echo e(__('Theme & Home')); ?></p>
            </a>
          </li>
        <?php endif; ?>



        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Menu Builder', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->path() == 'admin/menu-builder'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.menu_builder.index') . '?language=' . $defaultLang->code); ?>">
              <i class="fas fa-bars"></i>
              <p><?php echo e(__('Drag & Drop Menu Builder')); ?></p>
            </a>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Settings', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.basic_settings.favicon')): ?> active
            <?php elseif(request()->path() == 'admin/file-manager'): ?> active
            <?php elseif(request()->path() == 'admin/preloader'): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.logo')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.information')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.currency')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.appearance')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.mail_from_admin')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.mail_to_admin')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.mail_templates')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.edit_mail_template')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.social_links')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.edit_social_link')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.breadcrumb')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.page_headings')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.scripts')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.seo')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.maintenance_mode')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.cookie_alert')): ?> active
            <?php elseif(request()->routeIs('admin.basic_settings.footer_logo')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#basic_settings">
              <i class="la flaticon-settings"></i>
              <p><?php echo e(__('Settings')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="basic_settings" class="collapse
              <?php if(request()->routeIs('admin.basic_settings.favicon')): ?> show
              <?php elseif(request()->path() == 'admin/file-manager'): ?> show
              <?php elseif(request()->path() == 'admin/preloader'): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.logo')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.information')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.currency')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.appearance')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.mail_from_admin')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.mail_to_admin')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.mail_templates')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.edit_mail_template')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.social_links')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.edit_social_link')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.breadcrumb')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.page_headings')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.scripts')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.seo')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.maintenance_mode')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.cookie_alert')): ?> show
              <?php elseif(request()->routeIs('admin.basic_settings.footer_logo')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.favicon') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.favicon')); ?>">
                    <span class="sub-item"><?php echo e(__('Favicon')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.logo') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.logo')); ?>">
                    <span class="sub-item"><?php echo e(__('Logo')); ?></span>
                  </a>
                </li>
                <li class="<?php if(request()->path() == 'admin/preloader'): ?> active <?php endif; ?>">
                  <a href="<?php echo e(route('admin.preloader')); ?>">
                    <span class="sub-item"><?php echo e(__('Preloader')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.information') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.information')); ?>">
                    <span class="sub-item">Information</span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.currency') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.currency')); ?>">
                    <span class="sub-item"><?php echo e(__('Currency')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.appearance') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.appearance')); ?>">
                    <span class="sub-item"><?php echo e(__('Website Appearance')); ?></span>
                  </a>
                </li>
                <li class="submenu <?php if(request()->routeIs('admin.basic_settings.mail_from_admin')): ?> selected
                  <?php elseif(request()->routeIs('admin.basic_settings.mail_to_admin')): ?> selected
                  <?php elseif(request()->routeIs('admin.basic_settings.mail_templates')): ?> selected
                  <?php elseif(request()->routeIs('admin.basic_settings.edit_mail_template')): ?> selected <?php endif; ?>"
                >
                  <a data-toggle="collapse" href="#mail_settings">
                    <span class="sub-item"><?php echo e(__('Email Settings')); ?></span>
                    <span class="caret"></span>
                  </a>
                  <div id="mail_settings" class="collapse
                    <?php if(request()->routeIs('admin.basic_settings.mail_from_admin')): ?> show
                    <?php elseif(request()->routeIs('admin.basic_settings.mail_to_admin')): ?> show
                    <?php elseif(request()->routeIs('admin.basic_settings.mail_templates')): ?> show
                    <?php elseif(request()->routeIs('admin.basic_settings.edit_mail_template')): ?> show <?php endif; ?>"
                  >
                    <ul class="nav nav-collapse subnav">
                      <li class="<?php echo e(request()->routeIs('admin.basic_settings.mail_from_admin') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.basic_settings.mail_from_admin')); ?>">
                          <span class="sub-item"><?php echo e(__('Mail From Admin')); ?></span>
                        </a>
                      </li>
                      <li class="<?php echo e(request()->routeIs('admin.basic_settings.mail_to_admin') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.basic_settings.mail_to_admin')); ?>">
                          <span class="sub-item"><?php echo e(__('Mail To Admin')); ?></span>
                        </a>
                      </li>
                      <li class="<?php if(request()->routeIs('admin.basic_settings.mail_templates')): ?> active
                        <?php elseif(request()->routeIs('admin.basic_settings.edit_mail_template')): ?> active <?php endif; ?>"
                      >
                        <a href="<?php echo e(route('admin.basic_settings.mail_templates')); ?>">
                          <span class="sub-item"><?php echo e(__('Mail Templates')); ?></span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </li>
                <li class="<?php if(request()->path() == 'admin/file-manager'): ?> active <?php endif; ?>">
                  <a href="<?php echo e(route('admin.file-manager')); ?>">
                    <span class="sub-item">File Manager</span>
                  </a>
                </li>
                <li class="<?php if(request()->routeIs('admin.basic_settings.social_links')): ?> active 
                  <?php elseif(request()->routeIs('admin.basic_settings.edit_social_link')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.basic_settings.social_links')); ?>">
                    <span class="sub-item"><?php echo e(__('Social Links')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.breadcrumb') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.breadcrumb')); ?>">
                    <span class="sub-item"><?php echo e(__('Breadcrumb')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.page_headings') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.page_headings') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Page Headings')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.scripts') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.scripts')); ?>">
                    <span class="sub-item"><?php echo e(__('Plugins')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.seo') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.seo') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('SEO Informations')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.maintenance_mode') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.maintenance_mode')); ?>">
                    <span class="sub-item"><?php echo e(__('Maintenance Mode')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.cookie_alert') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.cookie_alert') . '?language=' . $defaultLang->code); ?>">
                    <span class="sub-item"><?php echo e(__('Cookie Alert')); ?></span>
                  </a>
                </li>
                <li class="<?php echo e(request()->routeIs('admin.basic_settings.footer_logo') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.basic_settings.footer_logo')); ?>">
                    <span class="sub-item"><?php echo e(__('Footer Logo')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Language Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->routeIs('admin.languages')): ?> active
            <?php elseif(request()->routeIs('admin.languages.edit_keyword')): ?> active <?php endif; ?>"
          >
            <a href="<?php echo e(route('admin.languages')); ?>">
              <i class="la flaticon-chat-8"></i>
              <p><?php echo e(__('Language Management')); ?></p>
            </a>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Admins Management', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->path() == 'admin/roles'): ?> active
            <?php elseif(request()->is('admin/role/*/permissions/manage')): ?> active
            <?php elseif(request()->path() == 'admin/users'): ?> active
            <?php elseif(request()->is('admin/user/*/edit')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#adminsManagement">
              <i class="fas fa-users-cog"></i>
              <p>Admins Management</p>
              <span class="caret"></span>
            </a>
            <div class="collapse
              <?php if(request()->path() == 'admin/roles'): ?> show
              <?php elseif(request()->is('admin/role/*/permissions/manage')): ?> show
              <?php elseif(request()->path() == 'admin/users'): ?> show
              <?php elseif(request()->is('admin/user/*/edit')): ?> show
              <?php endif; ?>" id="adminsManagement"
            >
              <ul class="nav nav-collapse">
                <li class="<?php if(request()->path() == 'admin/roles'): ?> active
                  <?php elseif(request()->is('admin/role/*/permissions/manage')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.role.index')); ?>">
                    <span class="sub-item">Roles & Permissions</span>
                  </a>
                </li>
                <li class="<?php if(request()->path() == 'admin/users'): ?> active
                  <?php elseif(request()->is('admin/user/*/edit')): ?> active <?php endif; ?>"
                >
                  <a href="<?php echo e(route('admin.user.index')); ?>">
                    <span class="sub-item">Admins</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>

        <?php if(empty($admin->role) || (!empty($permissions) && in_array('Sitemap', $permissions))): ?>
          
          <li class="nav-item <?php if(request()->path() == 'admin/sitemap'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.sitemap.index') . '?language=' . $defaultLang->code); ?>">
              <i class="fa fa-sitemap"></i>
              <p>Sitemap</p>
            </a>
          </li>
        <?php endif; ?>

        
        <li class="nav-item">
          <a href="<?php echo e(route('admin.cache.clear')); ?>">
            <i class="la flaticon-close"></i>
            <p>Clear Cache</p>
          </a>
        </li>

        
        <?php if(empty($admin->role) || (!empty($permissions) && in_array('QR Builder', $permissions))): ?>
          <li class="nav-item <?php if(request()->routeIs('admin.qrcode')): ?> active
            <?php elseif(request()->routeIs('admin.qrcode.index')): ?> active <?php endif; ?>"
          >
            <a data-toggle="collapse" href="#qrcode">
              <i class="fas fa-qrcode"></i>
              <p><?php echo e(__('QR Codes')); ?></p>
              <span class="caret"></span>
            </a>
            <div id="qrcode" class="collapse
              <?php if(request()->routeIs('admin.qrcode')): ?> show
              <?php elseif(request()->routeIs('admin.qrcode.index')): ?> show <?php endif; ?>"
            >
              <ul class="nav nav-collapse">
                <li class="<?php if(request()->routeIs('admin.qrcode')): ?> active <?php endif; ?>">
                  <a href="<?php echo e(route('admin.qrcode')); ?>">
                    <span class="sub-item"><?php echo e(__('Generate QR Code')); ?></span>
                  </a>
                </li>
                <li class="<?php if(request()->routeIs('admin.qrcode.index')): ?> active <?php endif; ?>">
                  <a href="<?php echo e(route('admin.qrcode.index')); ?>">
                    <span class="sub-item"><?php echo e(__('Saved QR Codes')); ?></span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</div>
<?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/partials/side_navbar.blade.php ENDPATH**/ ?>