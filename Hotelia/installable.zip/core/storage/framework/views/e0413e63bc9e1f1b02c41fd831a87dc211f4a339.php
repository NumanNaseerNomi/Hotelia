<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Edit Room')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Rooms Management')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Rooms')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Edit Room')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="card-title d-inline-block"><?php echo e(__('Update Room')); ?></div>
          <a
            class="btn btn-info btn-sm float-right d-inline-block"
            href="<?php echo e(route('admin.rooms_management.rooms')); ?>"
          >
            <span class="btn-label">
              <i class="fas fa-backward" style="font-size: 12px;"></i>
            </span>
            <?php echo e(__('Back')); ?>

          </a>
        </div>

        <div class="card-body pt-5 pb-5">
          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <div class="alert alert-danger pb-1" id="roomErrors" style="display: none;">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <ul></ul>
              </div>

              <form id="roomForm" action="<?php echo e(route('admin.rooms_management.update_room', ['id' => $room->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="form-group">
                  <label for=""><?php echo e(__('Featured Image*')); ?></label>
                  <br>
                  <div class="thumb-preview" id="thumbPreview1">
                    <img src="<?php echo e(asset('assets/img/rooms/' . $room->featured_img)); ?>" alt="room image">
                  </div>
                  <br><br>

                  <input type="hidden" id="fileInput1" name="featured_img">
                  <button
                    id="chooseImage1"
                    class="choose-image btn btn-primary"
                    type="button"
                    data-multiple="false"
                    data-toggle="modal"
                    data-target="#lfmModal1"
                  ><?php echo e(__('Choose Image')); ?></button>

                  
                  <div
                    class="modal fade lfm-modal"
                    id="lfmModal1"
                    tabindex="-1"
                    role="dialog"
                    aria-labelledby="lfmModalTitle"
                    aria-hidden="true"
                  >
                    <i class="fas fa-times-circle"></i>

                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                      <div class="modal-content">
                        <div class="modal-body p-0">
                          <iframe
                            src="<?php echo e(url('laravel-filemanager')); ?>?serial=1"
                            style="width: 100%; height: 500px; overflow: hidden; border: none;"
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                

                
                <div class="form-group my-3">
                  <label for=""><?php echo e(__('Slider Images*')); ?></label>
                  <br>
                  <div class="slider-thumbs" id="sliderThumbs2"></div>

                  <input type="hidden" id="fileInput2" name="slider_imgs">
                  <button
                    id="chooseImage2"
                    class="choose-image btn btn-primary mt-1"
                    type="button"
                    data-multiple="true"
                    data-toggle="modal"
                    data-target="#lfmModal2"
                  ><?php echo e(__('Choose Image')); ?></button>

                  
                  <div
                    class="modal fade lfm-modal"
                    id="lfmModal2"
                    tabindex="-1"
                    role="dialog"
                    aria-labelledby="lfmModalTitle"
                    aria-hidden="true"
                  >
                    <i class="fas fa-times-circle"></i>

                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                      <div class="modal-content">
                        <div class="modal-body p-0">
                          <iframe
                            id="lfmIframe2"
                            src="<?php echo e(url('laravel-filemanager')); ?>?serial=2&room=<?php echo e($room->id); ?>"
                            style="width: 100%; height: 500px; overflow: hidden; border: none;"
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                

                <div class="row">
                  <div class="col-lg-4">
                    <div class="form-group">
                      <label><?php echo e(__('Room Status*')); ?></label>
                      <select name="status" class="form-control">
                        <option disabled selected><?php echo e(__('Select a Status')); ?></option>
                        <option value="1" <?php echo e($room->status == 1 ? 'selected' : ''); ?>>
                          <?php echo e(__('Show')); ?>

                        </option>
                        <option value="0" <?php echo e($room->status == 0 ? 'selected' : ''); ?>>
                          <?php echo e(__('Hide')); ?>

                        </option>
                      </select>
                    </div>
                  </div>

                  <div class="col-lg-4">
                    <div class="form-group">
                      <label><?php echo e(__('Rent / Night')); ?> (in <?php echo e($websiteInfo->base_currency_text); ?>) *</label>
                      <input type="number" class="form-control" name="rent" placeholder="Enter Room Rent" value="<?php echo e($room->rent); ?>">
                    </div>
                  </div>

                  <div class="col-lg-4">
                    <div class="form-group">
                      <label><?php echo e(__('Quantity*')); ?></label>
                      <input type="number" class="form-control" name="quantity" placeholder="Enter No. Of Room" value="<?php echo e($room->quantity); ?>">
                    </div>
                  </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label><?php echo e(__('Beds *')); ?></label>
                        <input type="number" class="form-control" name="bed" placeholder="Enter No. Of Bed" value="<?php echo e($room->bed); ?>">
                      </div>
                    </div>
                  <div class="col-lg-4">
                    <div class="form-group">
                      <label><?php echo e(__('Baths *')); ?></label>
                      <input type="number" class="form-control" name="bath" placeholder="Enter No. Of Bath" value="<?php echo e($room->bath); ?>">
                    </div>
                  </div>

                  <div class="col-lg-4">
                    <div class="form-group">
                      <label><?php echo e(__('Max. Guests')); ?></label>
                      <input type="number" class="form-control" name="max_guests" placeholder="Enter maximum guests" value="<?php echo e($room->max_guests); ?>">
                      <p class="text-warning mb-0">Leave blank if you want to make it unlimited.</p>
                    </div>
                  </div>
                </div>

                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label><?php echo e(__('Latitude')); ?></label>
                            <input type="text" class="form-control" name="latitude" placeholder="Enter latitude for map" value="<?php echo e($room->latitude); ?>">
                            <p class="text-warning mb-0">Will be used to show in google map.</p>
                        </div>
                    </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label><?php echo e(__('Longitude')); ?></label>
                      <input type="text" class="form-control" name="longitude" placeholder="Enter longitude for map" value="<?php echo e($room->longitude); ?>">
                      <p class="text-warning mb-0">Will be used to show in google map.</p>
                    </div>
                  </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="form-group">
                        <label><?php echo e(__('Address')); ?></label>
                        <input type="text" class="form-control" name="address" placeholder="Enter Address" value="<?php echo e($room->address); ?>">
                        </div>
                    </div>

                  <div class="col-lg-4">
                    <div class="form-group">
                      <label><?php echo e(__('Phone')); ?></label>
                      <input type="text" class="form-control" name="phone" placeholder="Enter Phone" value="<?php echo e($room->phone); ?>">
                    </div>
                  </div>

                  <div class="col-lg-4">
                    <div class="form-group">
                      <label><?php echo e(__('Email')); ?></label>
                      <input type="email" class="form-control" name="email" placeholder="Enter Email" value="<?php echo e($room->email); ?>">
                    </div>
                  </div>
                </div>

                <div id="accordion" class="mt-5">
                  <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $roomContent = $language->roomDetails()->where('room_id', $room->id)->first();
                      $title = !empty($roomContent) ? $roomContent->title : '';
                      $categoryId = !empty($roomContent) ? $roomContent->room_category_id : '';
                      $summary = !empty($roomContent) ? $roomContent->summary : '';
                      $description = !empty($roomContent) ? $roomContent->description : '';
                      $meta_keywords = !empty($roomContent) ? $roomContent->meta_keywords : '';
                      $meta_description = !empty($roomContent) ? $roomContent->meta_description : '';
                    ?>

                    <div class="version">
                      <div class="version-header" id="heading<?php echo e($language->id); ?>">
                        <h5 class="mb-0">
                          <button
                            type="button"
                            class="btn btn-link"
                            data-toggle="collapse"
                            data-target="#collapse<?php echo e($language->id); ?>"
                            aria-expanded="<?php echo e($language->is_default == 1 ? 'true' : 'false'); ?>"
                            aria-controls="collapse<?php echo e($language->id); ?>"
                          >
                            <?php echo e($language->name . __(' Language')); ?> <?php echo e($language->is_default == 1 ? '(Default)' : ''); ?>

                          </button>
                        </h5>
                      </div>

                      <div
                        id="collapse<?php echo e($language->id); ?>"
                        class="collapse <?php echo e($language->is_default == 1 ? 'show' : ''); ?>"
                        aria-labelledby="heading<?php echo e($language->id); ?>"
                        data-parent="#accordion"
                      >
                        <div class="version-body">
                          <div class="row">
                            <div class="
                            <?php if($websiteInfo->room_category_status == 1): ?>
                            col-lg-6
                            <?php elseif($websiteInfo->room_category_status == 0): ?>
                            col-lg-12
                            <?php endif; ?>
                            ">
                              <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                <label><?php echo e(__('Room Title*')); ?></label>
                                <input type="text" class="form-control" name="<?php echo e($language->code); ?>_title" placeholder="Enter Title" value="<?php echo e(!empty($roomContent->title) ? $roomContent->title : ''); ?>">
                              </div>
                            </div>

                            <?php if($websiteInfo->room_category_status == 1): ?>
                            <div class="col-lg-6">
                              <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                <?php
                                  $categories = App\Models\RoomManagement\RoomCategory::where('language_id', $language->id)->where('status', 1)->get();
                                ?>

                                <label><?php echo e(__('Category*')); ?></label>
                                <select name="<?php echo e($language->code); ?>_category" class="form-control">
                                  <option disabled selected value=""><?php echo e(__('Select a Category')); ?></option>

                                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                      value="<?php echo e($category->id); ?>"
                                      <?php echo e($categoryId == $category->id ? 'selected' : ''); ?>

                                    ><?php echo e($category->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                            <?php endif; ?>
                          </div>

                          <div class="row">
                            <div class="col-lg-12">
                              <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                <?php
                                  $amenities = App\Models\RoomManagement\RoomAmenity::where('language_id', $language->id)->orderBy('serial_number', 'asc')->get();

                                  if (!empty($roomContent->amenities) && $roomContent->amenities != '[]') {
                                    $amenityData = json_decode($roomContent->amenities, true);
                                  } else {
                                    $amenityData = [];
                                  }
                                ?>

                                <label class="d-block"><?php echo e(__('Room Amenities*')); ?></label>
                                <?php if(!empty($amenities)): ?>
                                    <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-inline mr-3">
                                        <input type="checkbox" class="mr-1" name="<?php echo e($language->code); ?>_amenities[]" value="<?php echo e($amenity->id); ?>" <?php echo e(in_array($amenity->id, $amenityData) ? 'checked' : ''); ?>>
                                        <label for=""><?php echo e($amenity->name); ?></label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-lg-12">
                              <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                <label><?php echo e(__('Summary*')); ?></label>
                                <textarea class="form-control" name="<?php echo e($language->code); ?>_summary" placeholder="Enter Summary" rows="3"><?php echo e($summary); ?></textarea>
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-lg-12">
                              <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                <label><?php echo e(__('Room Description*')); ?></label>
                                <textarea class="form-control summernote" name="<?php echo e($language->code); ?>_description" placeholder="Enter Description" data-height="300" id="<?php echo e($language->code); ?>RoomDesc"><?php echo e(replaceBaseUrl($description, 'summernote')); ?></textarea>
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-lg-12">
                              <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                <label><?php echo e(__('Room Meta Keywords')); ?></label>
                                <input class="form-control" name="<?php echo e($language->code); ?>_meta_keywords" placeholder="Enter Meta Keywords" data-role="tagsinput" value="<?php echo e($meta_keywords); ?>">
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-lg-12">
                              <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                <label><?php echo e(__('Room Meta Description')); ?></label>
                                <textarea class="form-control" name="<?php echo e($language->code); ?>_meta_description" rows="5" placeholder="Enter Meta Description"><?php echo e($meta_description); ?></textarea>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" form="roomForm" class="btn btn-success">
                <?php echo e(__('Update')); ?>

              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script src="<?php echo e(asset('assets/js/admin-room.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/samiulalimpratik/Sites/hotelia/hotelia/core/resources/views/backend/rooms/edit_room.blade.php ENDPATH**/ ?>