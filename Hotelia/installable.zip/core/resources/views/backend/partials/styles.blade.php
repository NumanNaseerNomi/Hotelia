{{-- fontawesome css --}}
<link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">

{{-- fontawesome icon picker css --}}
<link rel="stylesheet" href="{{ asset('assets/css/fontawesome-iconpicker.min.css') }}">

{{-- dropzone css --}}
<link rel="stylesheet" href="{{ asset('assets/css/dropzone.css') }}">

{{-- jQuery dm-uploader css --}}
<link rel="stylesheet" href="{{ asset('assets/css/jquery.dm-uploader.min.css') }}">

{{-- bootstrap css --}}
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">

{{-- bootstrap tags-input css --}}
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap-tagsinput.css') }}">

{{-- jQuery-ui css --}}
<link rel="stylesheet" href="{{ asset('assets/css/jquery-ui.min.css') }}">

{{-- jQuery-timepicker css --}}
<link rel="stylesheet" href="{{ asset('assets/css/jquery.timepicker.min.css') }}">

{{-- bootstrap-datepicker css --}}
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap-datepicker.css') }}">

{{-- date-range-picker css --}}
<link rel="stylesheet" href="{{ asset('assets/css/daterangepicker.min.css') }}">

{{-- summernote css --}}
<link rel="stylesheet" href="{{ asset('assets/css/summernote-bs4.css') }}">

{{-- atlantis css --}}
<link rel="stylesheet" href="{{ asset('assets/css/atlantis.css') }}">

{{-- select2 css --}}
<link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

{{-- admin-main css --}}
<link rel="stylesheet" href="{{ asset('assets/css/admin-main.css') }}">
